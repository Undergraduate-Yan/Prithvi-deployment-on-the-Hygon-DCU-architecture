# S2. Dataset roles, preprocessing and access chronology

Sen1Floods11 supplies the flood case. Input bands are B02, B03, B04, B8A, B11 and B12, scaled by 1e-4 and resized to 224 x 224 using bilinear interpolation. Label resizing uses nearest-neighbor interpolation. Label -1 is ignored and label 1 is water. Flood normalization is embedded in the graph and must not be applied again outside it. Retained records do not fully identify every upstream band-resampling operation.

Separate sets of 64 training-derived scenes are used for calibration and configuration selection. The 89 official-validation images and 124 unused training images were not used for precision selection. The official-validation reserve, the 89 scenes with a defined per-scene flood mIoU, and the post-hoc clean-89 subset are three different concepts. The reserve is not presented as a completed independent evaluation.

CloudSEN12+ training comprises 5930 stored 509 x 509 observations from 1186 regions. Model validation comprises 535 observations from 107 regions, with 16 windows per observation (8560 model calls). A sample count, unique region count, crop/window count and inference-call count cannot be substituted for one another.

Formal cloud evaluation uses 300 previously unused 2000 x 2000 scenes. Both axes use tile starts {0, 224, 448, 672, 896, 1120, 1344, 1568, 1776}; their Cartesian product gives 81 calls per scene and 24,300 calls per variant. The final neighboring windows overlap by 16 pixels. Logits are averaged in overlaps before argmax and full-scene scoring. Scene reading, tiling, stitching and scoring are excluded from the model-call latency tables.

Cloud normalization is performed outside the graph using statistics from training regions only. A 975-sample, 195-region development evaluation is excluded from the 300-scene formal assessment. Disjointness is checked at the region, source-product, sample, generated-tile and content-hash levels, so the formal scene count is not inferred from a tile or observation count.

The access chronology in Table S3 establishes the evaluation roles. Events A01-A06 expose flood public-pool feedback before the C5 configuration and 13-segment topology are frozen. The stage-local counter at A08 measures only its own interval. A09 evaluates the frozen flood configuration descriptively, and A12 derives statistics from existing aggregate evidence without additional dataset access. These distinctions determine which results support configuration selection, descriptive assessment or independent formal evaluation.

## Table S2. Canonical data units and roles

| Task | Role | ROI/scene | Samples | Calls/sample | Status |
| --- | --- | --- | --- | --- | --- |
| Flood | official training | 431 | 431 | 1 | development only |
| Flood | calibration | 64 | 64 | 1 | quantization calibration only |
| Flood | configuration validation | 64 | 64 | 1 | precision selection and topology validation |
| Flood | official validation reserve | 89 | 89 | not accessed | not evaluated; future-confirmation eligibility not assessed |
| Flood | 90-image public-test pool | 90 | 90 | 1 per candidate | selection-exposed descriptive evaluation |
| Cloud | training | 1186 | 5930 | one random 224x224 crop per epoch | checkpoint training only |
| Cloud | model validation | 107 | 535 | 16 deterministic windows | checkpoint and early-stopping validation |
| Cloud | calibration | 256 | 1280 | registered calibration windows | quantization calibration only |
| Cloud | deployment validation | 256 | 1280 | registered deterministic windows | compile/numerical/system development |
| Cloud | 975-sample / 195-ROI development evaluation | 195 | 975 | registered windows | excluded from formal evaluation |
| Cloud | frozen 300-scene formal evaluation | 300 | 300 | 81 frozen 224x224 tiles | frozen formal evaluation |

ROI denotes region of interest. Counts of 5930 and 535 refer to sample observations rather than unique regions. The formal cloud evaluation comprises 300 full scenes.

CSV: `01_Data_and_Access/data_units.csv`

## Table S3. Project-level access chronology

| ID | Time | Task | n | Class | Scope |
| --- | --- | --- | --- | --- | --- |
| A01 | 2026-08-07 | Flood | 1 | selection-exposed | one image and target loaded for CPU/K100 mechanism check |
| A02 | 2026-08-07 | Flood | 90 | selection-exposed | complete FP32 evaluation with retained predictions |
| A03 | 2026-08-10 | Flood | 90 | selection-exposed | complete paired FP32/FP16 evaluation |
| A04 | 2026-08-10 | Flood | 90 | selection-exposed | complete mixed-provider INT8 diagnostic |
| A05 | 2026-08-10 | Flood | 90 | selection-exposed | complete strict-provider INT8 compatibility diagnostic |
| A06 | 2026-08-18 | Flood | 90 | selection-exposed | D0-D5 complete 90-image diagnostics; six candidates, three recorded runs each |
| A07 | 2026-08-20 | Flood | 90 | metadata-or-derived-only | identity and preprocessing replay; retained sample-ID/tensor misalignment reconstructed |
| A08 | 2026-08-22 | Flood | 0 | metadata-or-derived-only | stage-local ledger initialized at zero; not a project-level zero-access assertion |
| A09 | 2026-08-22 | Flood | 90 | inference-only | evaluation of the frozen configuration with per-scene predictions |
| A10 | 2026-08-24 | Cloud | 975 | inference-only | one evaluation-data access; excluded from the formal evaluation |
| A11 | 2026-08-25 | Cloud | 300 | inference-only | data materialized once; one formal evaluation per frozen variant; 24,300 calls per variant |
| A12 | 2026-08-28 | Flood and Cloud | 0 | metadata-or-derived-only | read-only confusion, margin, process-level latency CI, and clean-89 post-hoc derivations; no dataset payload or new inference |

Access dates establish the sequence of configuration development and evaluation. Flood public-pool results remain descriptive because the pool was accessed before configuration freezing.

CSV: `01_Data_and_Access/access_chronology.csv`
