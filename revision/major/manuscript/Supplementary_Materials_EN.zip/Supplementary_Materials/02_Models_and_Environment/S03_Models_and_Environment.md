# S3. Models, training, environment and artifact identities

The deployment uses Prithvi-EO-2.0-UPerNet with a single temporal observation and input shape 1 x 6 x 224 x 224. The 24 Transformer blocks are indexed B0-B23; the decoder consumes feature taps from B5, B11, B17 and B23. The flood head has two output channels and the cloud head has four, ordered clear, thick cloud, thin cloud and cloud shadow (IDs 0-3).

The retained state-dictionary audit records 318,968,578 flood parameters and 318,969,092 cloud parameters. Cloud adaptation freezes the encoder and trains 15,082,756 decoder/head parameters. Training draws one random tile per observation per epoch and applies horizontal and vertical flips independently with probability 0.5.

Cloud weighted cross-entropy uses class weights 0.55048897, 0.78021453, 1.31386861 and 1.35542790. AdamW uses batch size 16, learning rate 5e-5, weight decay 0.05, gradient clipping 1.0, mixed-16 training and cosine scheduling with T_max=50. Early stopping uses minimum improvement 1e-4 and patience 8. Seed 42 selects epoch 29 at validation loss 0.3213295043; 39 epochs were completed.

Artifact identity is established by ordered ONNX/MXR manifests containing hashes, file sizes and input/output contracts. A read-only inventory on Node 1 and Node 3 identifies 42 cloud ONNX files and 42 cloud MXR files on each node: 14 sessions for FP32, FP16 and the rejected mixed candidate. This identity coverage does not include a complete operator-level inventory of all remote graphs. Parameter totals are obtained from the task-model state-dictionary audit.

Node labels denote three independent hosts with Hygon K100 AI accelerator cards. A live available-RAM snapshot is not an experiment-time compilation limit. The 47 GiB guard within a 48 GiB process budget concerns host memory during the applicable compile transactions, not device VRAM or the RAM of every inference node.

## Table S4. Software roles and retained versions

| Component | Version / setting | Role |
| --- | --- | --- |
| Accelerator | Hygon K100 AI | Target inference platform |
| Host CPU | Hygon C86 5380; 16 cores / 32 threads; 2 NUMA nodes | Host execution |
| Host / container OS | Ubuntu 20.04 / Ubuntu 22.04.5 | Separate host and container identities |
| ONNX Runtime | 1.19.2 | Deployed inference |
| MIGraphX | 5.1.0 | Execution provider / compiler |
| DTK / HIP | 25.04.2 / 6.3.25405 | Accelerator toolchain |
| PyTorch / ONNX | 2.5.1 / 1.22.0 | Model preparation and export |
| ONNX Runtime | 1.26.0 | Offline quantization only; not the deployed inference runtime |



CSV: `02_Models_and_Environment/software_environment.csv`

## Table S5. Three-node hardware snapshot

| Node | Kernel | Cores/threads | NUMA | RAM (GiB) | Available (GiB) | Swap (GiB) |
| --- | --- | --- | --- | --- | --- | --- |
| Node1 | 5.4.0-198-generic | 16/32 | 2 | 62.78 | 52.71 | 0.00 |
| Node2 | 5.4.0-216-generic | 16/32 | 2 | 15.60 | 7.04 | 8.00 |
| Node3 | 5.4.0-189-generic | 16/32 | 2 | 62.78 | 53.57 | 0.00 |

Snapshot date: 28 August 2026. Available RAM is time-dependent and is not a compile budget.

CSV: `02_Models_and_Environment/hardware_snapshot.csv`

## Table S6. Frozen ONNX/cache identity coverage

| Role | Sessions | ONNX (GiB) | MXR (GiB) | Manifest boundary |
| --- | --- | --- | --- | --- |
| Cloud-14S-FP16 | 14 | 0.595 | 0.660 | Hash+I/O complete; operators/parameters not inspected |
| Cloud-14S-FP32 | 14 | 1.189 | 1.320 | Hash+I/O complete; operators/parameters not inspected |
| Cloud-14S-MP-X | 14 | 0.583 | 0.645 | Hash+I/O complete; operators/parameters not inspected |
| Flood-13S-FP16 | 13 | 0.595 | 0.660 | Hash+I/O complete; operators/parameters not inspected |
| Flood-13S-FP32 | 13 | 1.189 | 1.317 | Hash+I/O complete; operators/parameters not inspected |
| Flood-13S-MP | 13 | 0.420 | 0.491 | Hash+I/O complete; operators/parameters not inspected |
| Flood-1S-FP16 | 1 | 0.595 | 0.660 | Hash+I/O complete; operators/parameters not inspected |
| Flood-1S-FP32 | 1 | 1.189 | 1.317 | Hash+I/O complete; operators/parameters not inspected |

Sizes are independently rounded. ONNX + MXR rounded subtotals need not reproduce the rounded bundle total exactly. Public repository manifests identify external models and caches; additional unrestricted identity records can be requested from the corresponding author. Model and cache payloads are not included. See Section S11.

CSV: `02_Models_and_Environment/artifact_identity_coverage.csv`
