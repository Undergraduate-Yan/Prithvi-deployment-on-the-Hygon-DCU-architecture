# S4. Blockwise diagnostics and precision selection

The diagnostic flood topology contains 25 sessions: session 0 includes normalization, patch embedding and B0; sessions 1-23 isolate B1-B23; session 24 contains the UPerNet decoder/head. FP32 OrtValues connect adjacent sessions and retain the four feature taps. This topology provides observability and a controlled graph-coarsening reference.

Let $f_i^C$ and $f_i^K$ denote the CPU and K100 block implementations; $x_i^C$ and $x_i^K$ are their accumulated inputs.

Local discrepancy:

$$L_i=\operatorname{MAE}\!\left(f_i^C(x_i^C),f_i^K(x_i^C)\right).$$

Cumulative discrepancy:

$$C_i=\operatorname{MAE}\!\left(f_i^C(x_i^C),f_i^K(x_i^K)\right).$$

Propagated discrepancy:

$$P_i=\operatorname{MAE}\!\left(f_i^K(x_i^C),f_i^K(x_i^K)\right).$$

Only the local comparison holds the input fixed. The 64-scene campaign yields $64\times24=1536$ finite block records. In the table, $s_i$ denotes the local same-input relative-$l_2$ discrepancy.

C5 protects blocks {0, 8, 10, 14, 15, 17, 18, 19, 20} in FP16. The ranking uses descending P90 local relative-l2 error, then descending local MAE P90, descending local maximum-error P90 and ascending block index. The remaining 15 blocks retain INT8/QDQ ancestry and the decoder/head remains floating point. C5 is a deterministic feasible configuration, not a proof of a global precision optimum.

Quantization is static QDQ with signed weights and activations, per-channel symmetric weights, per-tensor asymmetric activations and MinMax calibration on 64 scenes. The retained target scope comprises one Conv and 144 MatMul operators; LayerNorm, Softmax, required additions/resizes and outputs stay floating point as specified by the graph. Source QDQ nodes and deployed integer kernels are distinct evidence layers.

D0-D5 test the relationship between precision assignment and CPU/K100 logit discrepancies on selection-exposed inputs. Their FP16 block sets are none; {0}; {0,14}; {0,14,17}; {0,14,17,18}; and {0,14,15,16,17,18,19,20,21}, respectively, with an FP32 head. The diagnostic limits are MAE <= 1e-3, maximum error <= 5e-2 and agreement >= 0.999. Full FP16 has MAE 0.003715 and maximum error 0.013458; D0-D5 MAE ranges from 0.092546 to 0.126587. These measurements do not support tight CPU/K100 logit equivalence.

C0-C5 and equal-count controls evaluate precision policies on the separate configuration set. Random seed 43 scores slightly higher than C5, supporting the feasibility and deterministic selection of the discrepancy-ranked map rather than a claim of universal superiority. The D5 mechanism diagnostic and D5 control use different data-materialization and runner procedures; their task values must be interpreted within those respective procedures.

## Table S7. Local same-input block statistics on 64 configuration scenes

| Block i | P90 L_i | Local max-abs P90 | P90 s_i | C5 role |
| --- | --- | --- | --- | --- |
| 0 | 0.416115 | 3.645593 | 0.253082 | FP16 |
| 1 | 0.079506 | 2.336992 | 0.051495 | Q/DQ ancestry |
| 2 | 0.078029 | 1.507330 | 0.048810 | Q/DQ ancestry |
| 3 | 0.075157 | 1.437344 | 0.045820 | Q/DQ ancestry |
| 4 | 0.064253 | 1.739475 | 0.040141 | Q/DQ ancestry |
| 5 | 0.067225 | 1.022279 | 0.041207 | Q/DQ ancestry |
| 6 | 0.076672 | 0.766407 | 0.043209 | Q/DQ ancestry |
| 7 | 0.073881 | 1.432684 | 0.042516 | Q/DQ ancestry |
| 8 | 0.104673 | 0.737910 | 0.063427 | FP16 |
| 9 | 0.077894 | 1.000237 | 0.047338 | Q/DQ ancestry |
| 10 | 0.100061 | 1.927614 | 0.062349 | FP16 |
| 11 | 0.095798 | 1.131810 | 0.060090 | Q/DQ ancestry |
| 12 | 0.061186 | 1.162358 | 0.043103 | Q/DQ ancestry |
| 13 | 0.084361 | 0.651716 | 0.053114 | Q/DQ ancestry |
| 14 | 0.134388 | 0.904192 | 0.084799 | FP16 |
| 15 | 0.112157 | 0.652954 | 0.066702 | FP16 |
| 16 | 0.102729 | 1.059689 | 0.061651 | Q/DQ ancestry |
| 17 | 0.143484 | 1.389992 | 0.084360 | FP16 |
| 18 | 0.132540 | 1.010867 | 0.075834 | FP16 |
| 19 | 0.117198 | 0.999497 | 0.063972 | FP16 |
| 20 | 0.117701 | 0.719143 | 0.064704 | FP16 |
| 21 | 0.111782 | 0.679559 | 0.058097 | Q/DQ ancestry |
| 22 | 0.041474 | 0.307386 | 0.019772 | Q/DQ ancestry |
| 23 | 0.046387 | 0.589615 | 0.019227 | Q/DQ ancestry |

P90 denotes the 90th percentile across the retained scenes. L_i is MAE; s_i is relative-l2 error. Q/DQ ancestry is a source-graph property, not by itself proof of an integer kernel.

CSV: `03_Precision_and_Graphs/blockwise_discrepancy_64.csv`

## Table S8. Configuration candidates and equal-resource controls

| Candidate | FP16 blocks | mIoU | Water IoU | Boundary IoU | Agreement |
| --- | --- | --- | --- | --- | --- |
| Ctrl_early | 0, 1, 2, 3, 4, 5, 6, 7, 8 | 0.834565 | 0.694706 | 0.324149 | 0.999613 |
| Ctrl_late | 15, 16, 17, 18, 19, 20, 21, 22, 23 | 0.834164 | 0.693890 | 0.323704 | 0.998065 |
| Ctrl_D5 | 0, 14, 15, 16, 17, 18, 19, 20, 21 | 0.834696 | 0.694956 | 0.323731 | 0.999197 |
| C0 | none | 0.833972 | 0.693522 | 0.322493 | 0.998040 |
| C1 | 0 | 0.834658 | 0.694879 | 0.323029 | 0.999154 |
| C2 | 0, 14 | 0.834727 | 0.694990 | 0.322548 | 0.999186 |
| C3 | 0, 14, 17 | 0.834588 | 0.694735 | 0.322621 | 0.999171 |
| C4 | 0, 14, 17, 18 | 0.834733 | 0.695018 | 0.322953 | 0.999174 |
| C5 | 0, 8, 10, 14, 15, 17, 18, 19, 20 | 0.834708 | 0.694988 | 0.323702 | 0.999192 |
| Ctrl_U42 | 0, 2, 3, 4, 7, 8, 19, 20, 22 | 0.834743 | 0.695052 | 0.323465 | 0.999357 |
| Ctrl_U43 | 0, 1, 3, 4, 9, 11, 14, 15, 20 | 0.834763 | 0.695082 | 0.323922 | 0.999369 |
| Ctrl_U44 | 0, 3, 5, 7, 9, 12, 13, 16, 17 | 0.834590 | 0.694761 | 0.322972 | 0.999287 |
| Ctrl_U45 | 0, 2, 8, 9, 10, 13, 15, 19, 23 | 0.834629 | 0.694859 | 0.323036 | 0.999261 |
| Ctrl_U46 | 1, 2, 4, 7, 12, 16, 18, 20, 21 | 0.833897 | 0.693378 | 0.322618 | 0.998186 |
| Ctrl_runtime | 0, 2, 5, 7, 16, 18, 19, 21, 23 | 0.834691 | 0.694968 | 0.323988 | 0.999283 |
| Ctrl_task-sensitivity | 0, 3, 9, 12, 13, 14, 15, 16, 20 | 0.834540 | 0.694673 | 0.323311 | 0.999236 |

All candidates use the training-derived configuration set. U42-U46 identify the random-seed controls. The public-pool flood results are reported separately in Table S14.

CSV: `03_Precision_and_Graphs/configuration_candidates.csv`
