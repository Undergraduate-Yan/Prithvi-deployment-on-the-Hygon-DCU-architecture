# S5. Graph restructuring and rejected candidates

The final 13-session flood graph coarsens the diagnostic topology while retaining required feature outputs. Groups are {B0-B1}, {B2}, {B3}, {B4}, {B5}, {B6}, {B7-B10}, {B11-B14 with B11 retained}, {B15-B16}, {B17-B18 with B17 retained}, {B19-B20}, {B21-B22}, and {B23 + decoder/head}. Groups that contain feature taps preserve those taps explicitly.

The retained 25-to-13 equivalence check records MAE 2.205997e-7, maximum absolute error 1.6689301e-6, relative-l2 error 1.3301186e-7 and prediction agreement 1.0. This is a same-precision graph-restructuring check on its retained inputs, not a statement that every precision candidate is task-equivalent.

Graph selection requires both semantic equivalence and compliance with the host-memory budget. Memory-limited candidates do not constitute completed deployments, and numerically invalid merges are excluded irrespective of their session-count reduction. The 22-session graph is an auxiliary branch for selected merge combinations; its incomplete independent timing prevents its use as a fully measured point in the 25-to-13 session comparison.

The rejected candidates in Table S10 characterize the feasible deployment space under the numerical and resource constraints. The single-session mixed graph was not launched after the bounded stopping decision, so neither accuracy nor performance is assigned to that configuration.

## Table S9. Retained topology lineage

| Task | Sessions | Role | Interpretation |
| --- | --- | --- | --- |
| Flood | 25S | root | block-isolated diagnostic topology |
| Flood | 22S | auxiliary branch | Flood-22S-MP-Aux auxiliary candidate; independent timing incomplete |
| Flood | 21S | main branch | corrected controlled merge |
| Flood | 20S | main branch | fully compiled controlled candidate |
| Flood | 18S | main branch | controlled probe |
| Flood | 16S | prepared probe | not promoted as a final identity |
| Flood | 15S | main branch | controlled probe |
| Flood | 14S | main branch | controlled probe |
| Flood | 13S | final fair topology | empirical floor under registered compile budget and candidate set |
| Flood | 1S | production branch | monolithic FP32/FP16 only |
| Cloud | 13S | failed transfer | graph-context numerical failure |
| Cloud | 14S | repaired final topology | weight-preserving split of the failing context |

Graph labels identify distinct candidate roles. Auxiliary and attempted graphs are not accepted deployments.

CSV: `03_Precision_and_Graphs/topology_lineage.csv`

## Table S10. Rejected or uncompleted restructuring candidates

| Task / candidate | Observed outcome | Interpretation |
| --- | --- | --- |
| Flood B0-B2 merge | Host RSS about 47.03 GiB | Exceeds the 47 GiB guard; unusable under the stated guard |
| Flood B7-B14 retaining B11; B21-head | Host RSS about 47.09 GiB | Memory gate failed |
| Flood B13-B16; B15-B18; B19-B22 | CPU semantic checks failed | Rejected before promotion |
| Flood 5-session mixed | Host RSS 53.92 GiB; no complete cache set | Resource-blocked attempt |
| Flood 1-session mixed | Not launched after bounded stopping | No completed artifact or timing |
| Cloud B21 / B22 mixed trials | 58 GiB stopping limit reached | Uncompleted resource-limited trials |
| Cloud B17 mixed trial | Outer termination | No accepted compiled candidate |
| Cloud B23 mixed trial | Valid compiled candidate; formal agreement failed | Retained negative task result |



CSV: `03_Precision_and_Graphs/rejected_candidates.csv`
