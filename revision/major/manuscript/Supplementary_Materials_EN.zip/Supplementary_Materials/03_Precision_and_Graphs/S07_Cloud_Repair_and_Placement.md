# S7. Cloud numerical repair, provider placement and kernels

The cloud 13-session decoder graph fails near the first ConvTranspose in session 12: the retained full-session maximum error is 17.0303498507. A context-preserving 13-node subgraph tested on 32 development samples reproduces a maximum error of 18.0425862074, while isolated-operator controls give 2.00e-5 and 8.58e-6. This localizes the problem to the tested graph context without proving a universal defect in the operator.

Adding one validated boundary creates a 14-session graph without changing learned weights. The development evaluation gives FP32 mIoU 0.701050, FP16 mIoU 0.701080 and agreement 0.999524. These development numbers are not the 300-scene formal results. Repair and precision decisions precede formal-scene access.

Execution-provider placement and realized kernels complement the numerical evaluation. For the flood FP32, FP16 and mixed configurations, the 13-session placement summaries identify MIGraphX execution for all sessions and zero CPU sessions. Device traces establish the realized kernel paths associated with source-graph Q/DQ structures. Configuration labels such as RCS13-FP16-A are resolved through ordered artifact hashes and tensor contracts.

The final flood mixed graph contains 210 QuantizeLinear, 270 DequantizeLinear and 176 Cast nodes in the retained accounting, together with trace counts 4809 I8II and 1134 HBH. Counts from shorter representative traces have their own 20-repeat denominator. They cannot be summed into, or used as a replacement for, the full retained trace. A realized INT8 path does not imply lower latency or acceptable segmentation agreement.

## Table S13. Representative kernel traces and their scope

| Task / session group | I8II count | HBH count | Scope |
| --- | --- | --- | --- |
| Flood B0-B1 | 320 | 120 | Representative 20-repeat trace |
| Flood B7-B10 | 560 | 240 | Representative 20-repeat trace |
| Flood B11-B14 | 860 | 120 | Representative 20-repeat trace |
| Flood B23 + head | 320 | Not stated here | Representative integer-path count |
| Cloud rejected B23 candidate | 120 | Not stated here | Candidate trace; task gate failed |
| Cloud retained FP16 session | Not stated here | 240 | Retained FP16 path |

I8II and HBH are retained kernel-category labels. Unreported counts are not treated as zero. These measurements establish path realization under their trace scopes.

CSV: `03_Precision_and_Graphs/representative_kernel_paths.csv`
