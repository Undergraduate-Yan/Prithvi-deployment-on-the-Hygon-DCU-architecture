# S8. Accuracy, paired uncertainty and sensitivity analyses

Flood scores on the previously accessed 90-image pool are descriptive. The bootstrap uses 10,000 paired scene resamples with seed 42. Undefined per-scene metrics are omitted only from the corresponding summary. Pooled confusion-derived mIoU and the mean of defined per-scene mIoU values are different estimands; subtracting two pooled table values need not reproduce the mean paired scene difference.

Flood Boundary IoU uses a symmetric two-pixel band: dilate foreground and background with a 5 x 5 neighborhood, intersect the dilations and apply the valid-pixel mask. Its fixed custom definition is part of the metric contract. Allowed decreases are 0.005 for mIoU and 0.01 for water and boundary IoU; agreement must be at least 0.995. Descriptive margin checks do not correct adaptive-selection bias.

The clean-89 sensitivity analysis removes runtime index 0, whose recorded label Ghana_313799 differs from its actual source Ghana_1078550. The analysis assesses the influence of that source-identity discrepancy on the exposed public-pool results. As a post-hoc subset of the same pool, it is distinct from the unused official 89-image validation reserve and does not provide independent confirmation.

Cloud decisions use the frozen 300-scene protocol with 10,000 paired scene-bootstrap resamples and one-sided 95% lower bounds. Allowed decreases are 0.005 for mIoU and macro-F1, 0.01 for per-class IoU, and 0.005 for agreement relative to the FP32 reference agreement of 1. A lower bound on agreement difference is compared with -0.005. It is not an absolute agreement value.

FP16 meets the retained cloud criteria. The mixed candidate has observed agreement 0.994727 and a paired lower bound of -0.005969 on agreement difference, so it fails. Improvements in bundle size or latency do not reverse this decision. No replacement was selected using formal-set feedback.

The exploratory margin-sensitivity table varies hypothetical thresholds using already retained lower bounds. It is a descriptive sensitivity display; the registered decisions and tolerances remain unchanged. Class precision/recall/F1 are derived from retained confusion matrices with true labels as rows and predictions as columns.

## Table S14. Descriptive flood segmentation results

| Sessions | Precision | mIoU | Water IoU | Boundary IoU | Agreement |
| --- | --- | --- | --- | --- | --- |
| 1 | FP32 | 0.860587 | 0.757838 | 0.362581 | 1.000000 |
| 13 | FP32 | 0.860587 | 0.757838 | 0.362581 | 1.000000 |
| 13 | FP16 | 0.860443 | 0.757566 | 0.361941 | 0.999813 |
| 1 | FP16 | 0.860440 | 0.757563 | 0.361936 | 0.999814 |
| 13 | Mixed C5 | 0.860740 | 0.758114 | 0.363108 | 0.998745 |

Corresponds to manuscript Table 3. All scores describe the 90-image public pool, which was accessed during configuration development.

CSV: `04_Accuracy_and_Statistics/flood_accuracy.csv`

## Table S15. Flood paired scene-bootstrap descriptive screen

| Candidate | Metric | Difference | Lower 95% | Margin | Status |
| --- | --- | --- | --- | --- | --- |
| Flood-25S-D5-Control | miou | -0.000087 | -0.000802 | -0.005 | Within descriptive margin |
| Flood-25S-D5-Control | water_iou | -0.000218 | -0.001724 | -0.010 | Within descriptive margin |
| Flood-25S-D5-Control | Boundary IoU | -0.000094 | -0.001683 | -0.010 | Within descriptive margin |
| Flood-25S-D5-Control | agreement | -0.001332 | -0.001758 | -0.005 | Within descriptive margin |
| Flood-13S-MP | miou | -0.000211 | -0.000833 | -0.005 | Within descriptive margin |
| Flood-13S-MP | water_iou | -0.000494 | -0.001750 | -0.010 | Within descriptive margin |
| Flood-13S-MP | Boundary IoU | 0.000384 | -0.000704 | -0.010 | Within descriptive margin |
| Flood-13S-MP | agreement | -0.001304 | -0.001738 | -0.005 | Within descriptive margin |
| Flood-1S-FP16 | miou | -0.000268 | -0.000400 | -0.005 | Within descriptive margin |
| Flood-1S-FP16 | water_iou | -0.000569 | -0.000840 | -0.010 | Within descriptive margin |
| Flood-1S-FP16 | Boundary IoU | -0.000363 | -0.000757 | -0.010 | Within descriptive margin |
| Flood-1S-FP16 | agreement | -0.000189 | -0.000253 | -0.005 | Within descriptive margin |
| Flood-1S-FP32 | miou | 0.000000 | 0.000000 | -0.005 | Within descriptive margin |
| Flood-1S-FP32 | water_iou | 0.000000 | 0.000000 | -0.010 | Within descriptive margin |
| Flood-1S-FP32 | Boundary IoU | 0.000000 | 0.000000 | -0.010 | Within descriptive margin |
| Flood-1S-FP32 | agreement | 0.000000 | 0.000000 | -0.005 | Within descriptive margin |
| Flood-13S-FP16 | miou | -0.000253 | -0.000381 | -0.005 | Within descriptive margin |
| Flood-13S-FP16 | water_iou | -0.000538 | -0.000796 | -0.010 | Within descriptive margin |
| Flood-13S-FP16 | Boundary IoU | -0.000329 | -0.000732 | -0.010 | Within descriptive margin |
| Flood-13S-FP16 | agreement | -0.000191 | -0.000254 | -0.005 | Within descriptive margin |

Difference is candidate minus its paired reference for the stated scene-level metric. The retained mean paired mIoU differences are not differences of pooled mIoU values. No independent-confirmation interpretation is made.

CSV: `04_Accuracy_and_Statistics/flood_descriptive_bootstrap.csv`

## Table S16. Post-hoc clean-89 flood sensitivity

| Role | mIoU | Water IoU | Boundary IoU | Pixel acc. | Agreement |
| --- | --- | --- | --- | --- | --- |
| Flood-13S-MP | 0.861906 | 0.760366 | 0.365063 | 0.967244 | 0.998736 |
| Flood-13S-FP16 | 0.861607 | 0.759816 | 0.363858 | 0.967196 | 0.999810 |
| Flood-13S-FP32 | 0.861751 | 0.760088 | 0.364506 | 0.967214 | 1.000000 |

Removal of runtime index 0 is post hoc and does not create an independent test set.

CSV: `04_Accuracy_and_Statistics/flood_clean89_posthoc.csv`

## Table S17. Formal cloud segmentation results

| Metric | FP32 | FP16 | Mixed candidate |
| --- | --- | --- | --- |
| mIoU | 0.612601 | 0.612581 | 0.612098 |
| Macro-F1 | 0.736891 | 0.736860 | 0.736416 |
| Pixel accuracy | 0.866554 | 0.866591 | 0.866405 |
| Clear IoU | 0.867286 | 0.867366 | 0.866653 |
| Thick-cloud IoU | 0.788892 | 0.788902 | 0.789275 |
| Thin-cloud IoU | 0.411542 | 0.411500 | 0.409902 |
| Cloud-shadow IoU | 0.382683 | 0.382556 | 0.382562 |
| Agreement | 1.000000 | 0.999371 | 0.994727 |
| mIoU difference lower bound | Reference | -0.000089 | -0.001370 |
| Agreement difference lower bound | Reference | -0.000725 | -0.005969 |
| Decision | Reference | Accepted | Rejected |

Corresponds to manuscript Table 7. All variants use the 14-session cloud topology. The formal evaluation contains 300 full scenes and 24,300 tile calls per variant.

CSV: `04_Accuracy_and_Statistics/cloud_accuracy.csv`

## Table S18. Complete formal cloud paired scene-bootstrap results

| Candidate | Metric | Difference | Lower 95% | Margin | Status |
| --- | --- | --- | --- | --- | --- |
| Cloud-14S-FP16 | mIoU | -0.000020 | -0.000089 | -0.005 | PASS |
| Cloud-14S-FP16 | MacroF1 | -0.000031 | -0.000096 | -0.005 | PASS |
| Cloud-14S-FP16 | clear_IoU | 0.000079 | 0.000021 | -0.010 | PASS |
| Cloud-14S-FP16 | thick_cloud_IoU | 0.000010 | -0.000069 | -0.010 | PASS |
| Cloud-14S-FP16 | thin_cloud_IoU | -0.000042 | -0.000210 | -0.010 | PASS |
| Cloud-14S-FP16 | cloud_shadow_IoU | -0.000127 | -0.000263 | -0.010 | PASS |
| Cloud-14S-FP16 | agreement | -0.000629 | -0.000725 | -0.005 | PASS |
| Cloud-14S-MP-X | mIoU | -0.000503 | -0.001370 | -0.005 | PASS |
| Cloud-14S-MP-X | MacroF1 | -0.000475 | -0.001307 | -0.005 | PASS |
| Cloud-14S-MP-X | clear_IoU | -0.000634 | -0.001272 | -0.010 | PASS |
| Cloud-14S-MP-X | thick_cloud_IoU | 0.000383 | -0.000461 | -0.010 | PASS |
| Cloud-14S-MP-X | thin_cloud_IoU | -0.001640 | -0.003737 | -0.010 | PASS |
| Cloud-14S-MP-X | cloud_shadow_IoU | -0.000121 | -0.002217 | -0.010 | PASS |
| Cloud-14S-MP-X | agreement | -0.005273 | -0.005969 | -0.005 | FAIL |

Difference is candidate minus reference; bounds are one-sided 95% lower bounds. PASS/FAIL is retained per criterion. The mixed candidate is rejected because of agreement.

CSV: `04_Accuracy_and_Statistics/cloud_formal_bootstrap.csv`

## Table S19. Cloud absolute class and binary aggregation metrics

| Role | Aggregation | Class | Prev. | Precision | Recall | F1 | IoU |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Cloud-14S-FP32 | four_class | Clear | 0.6489 | 0.9112 | 0.9473 | 0.9289 | 0.8673 |
| Cloud-14S-FP32 | four_class | Thick Cloud | 0.1961 | 0.9188 | 0.8481 | 0.8820 | 0.7889 |
| Cloud-14S-FP32 | four_class | Thin Cloud | 0.0834 | 0.5437 | 0.6287 | 0.5831 | 0.4115 |
| Cloud-14S-FP32 | four_class | Cloud Shadow | 0.0715 | 0.6901 | 0.4621 | 0.5535 | 0.3827 |
| Cloud-14S-FP32 | clear_vs_any_cloud | Any Cloud | 0.3511 | 0.8949 | 0.8295 | 0.8609 | 0.7558 |
| Cloud-14S-FP16 | four_class | Clear | 0.6489 | 0.9112 | 0.9474 | 0.9290 | 0.8674 |
| Cloud-14S-FP16 | four_class | Thick Cloud | 0.1961 | 0.9187 | 0.8481 | 0.8820 | 0.7889 |
| Cloud-14S-FP16 | four_class | Thin Cloud | 0.0834 | 0.5437 | 0.6286 | 0.5831 | 0.4115 |
| Cloud-14S-FP16 | four_class | Cloud Shadow | 0.0715 | 0.6907 | 0.4617 | 0.5534 | 0.3826 |
| Cloud-14S-FP16 | clear_vs_any_cloud | Any Cloud | 0.3511 | 0.8951 | 0.8294 | 0.8610 | 0.7559 |

Prev. means class prevalence. The any-cloud aggregation combines the three non-clear classes. Rounded display metrics do not replace the retained full-precision confusion matrices.

CSV: `04_Accuracy_and_Statistics/cloud_class_metrics.csv`

## Table S20. Exploratory practical-margin sensitivity

| Task | Role | Metric | Lower bound | .0001 | .0005 | .001 | .0025 | .005 | .01 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| flood | Flood-13S-MP | miou | -8.328e-04 | Fail | Fail | Pass | Pass | Pass | Pass |
| flood | Flood-13S-FP16 | miou | -3.811e-04 | Fail | Pass | Pass | Pass | Pass | Pass |
| cloud | Cloud-14S-FP16 | mIoU | -8.916e-05 | Pass | Pass | Pass | Pass | Pass | Pass |
| cloud | Cloud-14S-MP-X | agreement | -5.969e-03 | Fail | Fail | Fail | Fail | Fail | Pass |

Threshold columns are hypothetical tolerated decreases. Registered acceptance decisions are unchanged.

CSV: `04_Accuracy_and_Statistics/margin_sensitivity.csv`
