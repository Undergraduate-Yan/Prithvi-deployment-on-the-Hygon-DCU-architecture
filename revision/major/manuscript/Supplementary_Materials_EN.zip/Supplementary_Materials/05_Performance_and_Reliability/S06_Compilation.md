# S6. Compilation and deployment-bundle accounting

A deployment bundle comprises retained ONNX files plus compiled MXR caches. Its size is distinct from peak host RSS during compilation and incremental device memory during inference. GiB uses 2^30 bytes. Peak RSS is a peak measurement; compilation durations may cover all graph creation or only newly compiled sessions.

Table S11 reports complete-graph compilation costs. The 13-session mixed-precision time is a lower bound because durations for reused sessions are unavailable. Table S12 reports a selected-merge measurement of 1580.113591 s and 3.288097 GiB. That measurement covers a subset of graph construction, whereas the deployment-level accounting is >=2080.613 s and 3.978 GiB. The two records quantify different measurement scopes.

Cloud graph repair reuses 12 sessions and rebuilds two. Its incremental compilation measurements are FP32: 439.117 s and 3.270 GiB peak RSS; FP16: 473.783 s and 3.091 GiB. These are repair-only costs, not full cold-build totals. The retained cloud bundle sizes are 2,694,875,810 bytes (FP32), 1,347,179,966 bytes (FP16) and 1,319,407,483 bytes (rejected mixed candidate).

## Table S11. Flood complete-graph compilation costs and deployment-bundle size

| Sessions | Precision | Bundle (GiB) | Peak host RSS (GiB) | Compile time (s) |
| --- | --- | --- | --- | --- |
| 1 | FP16 | 1.255 | 7.640 | 1517.760 |
| 13 | FP32 | 2.506 | 4.233 | 1642.890 |
| 13 | FP16 | 1.255 | 4.048 | 1600.524 |
| 13 | Mixed C5 | 0.912 | 3.978 | >=2080.613 |

Corresponds to manuscript Table 5. Mixed-precision compilation time is a lower bound because reused-session durations are missing.

CSV: `05_Performance_and_Reliability/flood_compile.csv`

## Table S12. Compilation measurements by graph-construction scope

| Record | Role | S | Time (s) | Peak (GiB) | Scope |
| --- | --- | --- | --- | --- | --- |
| Initial uninstrumented record | Flood-1S-FP16-Diagnostic | 1 | not retained | not retained | timing not instrumented |
| Fresh single-Session build | Flood-1S-FP16 | 1 | 1517.759806 | 7.640 | Session creation; outer wall 1519.651678 s |
| 1S FP32 record | Flood-1S-FP32 | 1 | 1514.97598185 | not instrumented | complete retained compile records |
| 25S FP32 record | Flood-25S-FP32 | 25 | 1408.2397988880984 | not instrumented | complete retained compile records |
| 25S D5 control record | Flood-25S-D5-Control | 25 | not retained | not instrumented | timing not available |
| 5S mixed attempt | Flood-5S-MP-Attempt | 5 | not retained | 53.92 | blocked; no complete cache set |
| 1S mixed stop | Flood-1S-MP-Attempt | 1 | not launched | not instrumented | not launched after bounded stop |
| 22S auxiliary branch | Flood-22S-MP-Aux | 22 | 308.938867 | 3.553993 | selected merges only; reused time unavailable |
| 20S controlled branch | Flood-20S-MP | 20 | 567.435395 | 3.553993 | selected merges only; reused time unavailable |
| 13S mixed record | Flood-13S-MP | 13 | 1580.113591 | 3.288097 | selected merges only; reused time unavailable |

The 13S mixed-precision measurement in this table covers selected merges. Complete-graph accounting is reported in Table S11. Unavailable and uninstrumented measurements remain explicitly identified.

CSV: `05_Performance_and_Reliability/compile_measurement_scopes.csv`
