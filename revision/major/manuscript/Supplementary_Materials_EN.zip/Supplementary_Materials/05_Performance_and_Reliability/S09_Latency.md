# S9. Controlled latency and process-level uncertainty

Controlled short-run measurements use five fresh processes per node and variant, 50 warm-up calls and 200 measured calls per process, giving 1000 measured calls. CPU affinity is fixed and competing accelerator processes are excluded. Common C++ Runner-A timing includes every session, final synchronization and the transfer of FP32 logits to the host.

The single-session flood comparison uses a separately fixed Python I/O-binding runner. Comparisons should be made within runner, topology and node. A cross-runner difference does not isolate the effect of graph segmentation or precision. The cloud comparison holds the 14-session topology and Runner-A fixed.

The manuscript reports pooled-call medians and tail percentiles. The process-level analysis reports the median of five process medians and bootstraps those process-level values with 10,000 replicates and seed 42. It estimates between-process uncertainty under the same measurement protocol. Its interpretation is limited by the number of processes and by the exclusion of scene loading, tiling, stitching and scoring.

Configuration-validation measurements use 3 x 100 or 10 x 200 diagnostic calls to characterize graph-reduction candidates. Their scope differs from the five-process controlled deployment benchmark. Sustained-loop throughput additionally includes scheduling, telemetry and integrity checks. Each measurement addresses a distinct aspect of deployment behavior and is reported with its corresponding protocol.

## Table S21. Controlled flood model-call latency

| Runner / topology | Node | Precision | Median (ms) | P95 (ms) | P99 (ms) |
| --- | --- | --- | --- | --- | --- |
| Python / 1S | 2 | FP32 | 19.133 | 21.086 | 23.698 |
| Python / 1S | 2 | FP16 | 14.704 | 16.661 | 19.321 |
| Python / 1S | 3 | FP32 | 19.858 | 22.267 | 25.075 |
| Python / 1S | 3 | FP16 | 15.288 | 16.962 | 20.225 |
| Runner-A / 13S | 2 | FP32 | 34.912 | 36.967 | 40.040 |
| Runner-A / 13S | 2 | FP16 | 32.094 | 33.981 | 36.737 |
| Runner-A / 13S | 2 | Mixed C5 | 39.180 | 41.257 | 43.651 |
| Runner-A / 13S | 3 | FP32 | 33.153 | 35.217 | 36.776 |
| Runner-A / 13S | 3 | FP16 | 30.132 | 31.565 | 32.680 |
| Runner-A / 13S | 3 | Mixed C5 | 37.932 | 39.843 | 40.930 |

Corresponds to manuscript Table 4. Each row includes 1000 measured calls across five processes.

CSV: `05_Performance_and_Reliability/flood_latency.csv`

## Table S22. Cloud model-call latency on the 14-session topology

| Node | Precision | Median (ms) | P95 (ms) | P99 (ms) |
| --- | --- | --- | --- | --- |
| 1 | FP32 | 36.612 | 42.179 | 49.653 |
| 1 | FP16 | 33.060 | 38.302 | 44.318 |
| 1 | Mixed candidate | 32.267 | 36.880 | 42.507 |
| 3 | FP32 | 34.528 | 37.503 | 45.223 |
| 3 | FP16 | 31.006 | 34.473 | 40.878 |
| 3 | Mixed candidate | 30.884 | 33.870 | 39.904 |

Corresponds to manuscript Table 8. The mixed candidate fails the task-agreement requirement despite its measured latency.

CSV: `05_Performance_and_Reliability/cloud_latency.csv`

## Table S23. Cloud process-level latency uncertainty

| Node | Role | Processes | Calls | Median of medians (ms) | 95% CI (ms) |
| --- | --- | --- | --- | --- | --- |
| Node1 | Cloud-14S-FP16 | 5 | 1000 | 32.701 | [32.423, 33.971] |
| Node1 | Cloud-14S-FP32 | 5 | 1000 | 36.600 | [35.961, 37.608] |
| Node1 | Cloud-14S-MP-X | 5 | 1000 | 32.422 | [31.647, 32.707] |
| Node3 | Cloud-14S-FP16 | 5 | 1000 | 30.805 | [30.711, 31.598] |
| Node3 | Cloud-14S-FP32 | 5 | 1000 | 34.508 | [34.313, 34.854] |
| Node3 | Cloud-14S-MP-X | 5 | 1000 | 30.846 | [30.495, 31.375] |

Median of process medians differs from the pooled-call median in the preceding table. Confidence intervals use the retained five fresh-process medians.

CSV: `05_Performance_and_Reliability/cloud_process_latency_ci.csv`

## Table S24. Configuration-validation latency for graph-reduction candidates

| Configuration | Protocol | S | Calls | Median (ms) | P95 (ms) |
| --- | --- | --- | --- | --- | --- |
| Flood-1S-FP32 | 3 x 100 characterization | 1 | 300 | 17.197 | 18.934 |
| Flood-1S-FP16-Diagnostic | 3 x 100 characterization | 1 | 300 | 13.324 | 13.717 |
| Flood-25S-FP32 | 3 x 100 characterization | 25 | 300 | 20.847 | 22.594 |
| Flood-25S-D5-Control | 3 x 100 characterization | 25 | 300 | 21.373 | 23.558 |
| Flood-13S-MP | 3 x 100 characterization | 13 | 300 | 19.253 | 21.274 |
| Flood-1S-FP32 | 10 x 200 repeat characterization | 1 | 2000 | 17.278 | 20.815 |
| Flood-1S-FP16-Diagnostic | 10 x 200 repeat characterization | 1 | 2000 | 13.393 | 13.888 |
| Flood-13S-MP | 10 x 200 repeat characterization | 13 | 2000 | 19.263 | 21.534 |

These configuration-validation protocols characterize graph-reduction candidates and are separate from the five-process controlled benchmark.

CSV: `05_Performance_and_Reliability/configuration_graph_reduction_latency.csv`
