# S10. Runtime resources, startup, recovery and sustained operation

Incremental device memory is distinct from the ONNX+MXR bundle on disk. The flood resource experiment samples device memory at 20 Hz and power at 10 Hz; energy per completed call is obtained by trapezoidal integration. Flood energy is gross energy per model call. Cloud energy subtracts idle power and is incremental energy per tile; these two energy measures are not directly comparable.

Startup spans process initialization through the first valid prediction while retaining filesystem caches. Recovery follows deliberate process termination and restart. Flood startup and recovery use ten and five valid repetitions, respectively. These definitions are not a measurement of spacecraft boot or radiation-fault recovery.

The isolated flood FP32 stability experiment on Node 2 runs for 3600.004154 s and completes 151,580 calls with zero errors, non-finite outputs or prediction drift. All 719 active KFD telemetry records belong to the experiment, with no foreign KFD records. This exclusivity condition supports attribution of the monitored device activity to the evaluated configuration.

A separate partly shared FP32 experiment on Node 3 completes 165,912 calls. Because device exclusivity is incomplete, this run is excluded from the isolated comparison in Table S25 and manuscript Table 6. The distinction is based on measurement conditions and prevents competing device activity from being interpreted as a precision effect.

Flood FP16 and mixed sustained records complete 215,971 and 151,370 calls, respectively, in approximately one hour, without recorded errors or non-finite outputs. Cloud sustained records complete 139,017 FP32 calls on Node 3 and 145,192 FP16 calls on Node 2 over their retained durations. Cross-node system differences are descriptive and cannot be attributed to precision alone.

Sustained loops include monitoring and integrity checks. Their calls-per-second rates must not be substituted for the controlled short-run latency statistics. Zero observed failures in these runs is an observation over these durations and conditions, not an estimate of unrestricted mission reliability.

## Table S25. Flood runtime resources and sustained-operation results

| Metric | 1S FP32 | 1S FP16 | 13S Mixed C5 |
| --- | --- | --- | --- |
| Incremental device memory (GiB) | 4.817 | 3.149 | 10.682 |
| Gross energy (J/call) | 5.352 | 3.531 | 4.653 |
| Median startup (s) | 23.115 | 18.723 | 17.033 |
| Median recovery (s) | 33.988 | 29.090 | 27.819 |
| Calls in approximately 3600 s | 151580 | 215971 | 151370 |
| Errors / non-finite outputs | 0 / 0 | 0 / 0 | 0 / 0 |

Corresponds to manuscript Table 6. The FP32 sustained-operation result uses the isolated Node 2 experiment. The partly shared Node 3 experiment is excluded from this comparison.

CSV: `05_Performance_and_Reliability/flood_runtime.csv`

## Table S26. Cloud runtime resources and sustained-operation results

| Metric | FP32 | FP16 |
| --- | --- | --- |
| Resource-measurement node | 3 | 1 |
| Incremental device memory (GiB) | 12.462 | 10.893 |
| Incremental energy above idle (J/tile) | 4.890 | 1.957 |
| Median startup (s) | 29.187 | 25.769 |
| Median recovery (s) | 28.986 | 25.774 |
| Sustained-operation node | 3 | 2 |
| Duration (s) | 5111.418 | 5349.822 |
| Completed calls | 139017 | 145192 |
| Errors / prediction drift | 0 / 0 | 0 / 0 |

Corresponds to manuscript Table 9. Resource and sustained-operation measurements use different node assignments; cross-node differences do not isolate precision effects.

CSV: `05_Performance_and_Reliability/cloud_runtime.csv`
