# S1. Research scope and evaluation framework

This study investigates the deployment of remote sensing foundation models on the Hygon DCU architecture under joint constraints on numerical compatibility, compilation memory, deployment capacity and inference performance. Prithvi-EO-2.0-UPerNet is evaluated on flood and cloud segmentation to examine how precision assignment and execution-graph restructuring affect task predictions and computational requirements.

The two tasks provide different forms of evidence. The flood experiments characterize blockwise discrepancies, precision configurations and graph partitions, with final task scores reported descriptively because the 90-image public pool was accessed during development. The cloud experiments assess a frozen deployment on 300 previously unused, region-disjoint scenes. The separate 64-scene flood configuration set limits subsequent selection exposure but does not remove the effect of earlier public-pool feedback.

The evaluation distinguishes task accuracy, execution-provider placement, realized kernel paths, controlled latency and sustained-operation behavior. Their joint assessment is necessary because numerical agreement alone does not establish accelerator execution or performance, while smaller deployment files and faster kernels do not establish task acceptance. All experiments use ground-based K100 hardware; in-orbit operation, radiation qualification and spacecraft-level power or reliability are outside the demonstrated scope.

The supplementary analyses specify the dataset roles, model and software configurations, numerical diagnostics, graph-selection criteria, statistical procedures and measurement boundaries supporting the manuscript. Tables S1-S27 provide the associated quantitative evidence, and the accompanying CSV files make the tabulated results accessible for inspection. Data and artifact access conditions are described in Section S11.

## Table S1. Correspondence between the manuscript and supplementary evidence

| Manuscript location | Supplement sections | Evidence / scope |
| --- | --- | --- |
| 2.1-2.2; Table 1 | S3 | Model dimensions, task training, environment and artifact identity coverage |
| 2.3.1; 3.1.3; Table 5 | S5-S6 | Graph lineage, rejected merges and separately scoped compile costs |
| 2.3.2; 3.1.1 | S4 | Local diagnostics, C0-C5 candidates and equal-resource controls |
| 2.4; Table 2 | S2; S8 | Flood access events A01-A09, descriptive accuracy and bootstrap |
| 2.5; Table 2 | S2-S3; S7-S8 | Cloud training, independent formal scenes, repair and task acceptance |
| 3.1.2; Table 4; 3.2.3; Table 8 | S9 | Controlled model-call timing; process-level uncertainty |
| 3.1.3; Table 6; 3.2.3; Table 9 | S10 | Runtime memory, energy, startup, recovery and sustained loops |
| 4-5; Supplementary / Data Availability statements | S1; S11 | Reproducibility and access limits; no in-orbit validation |

Section numbers refer to the manuscript and this supplement.

CSV: `06_Provenance_and_Checks/manuscript_evidence_map.csv`
