# Supplementary Materials

## Associated article

Onboard Deployment of Remote Sensing Foundation Models for the Hygon DCU Architecture

These materials describe the data, methods and evidence supporting the study of remote sensing foundation-model deployment on Hygon K100 accelerators. They connect numerical compatibility and graph structure to segmentation accuracy, compilation resources, model-call latency and sustained-operation behavior.

## Contents

- `Supplementary_Materials.pdf`: Sections S1-S11 and Tables S1-S27.
- `Supplementary_Materials.md`: the complete text with mathematical definitions and tables.
- `01_Data_and_Access/`: dataset units, preprocessing and access chronology.
- `02_Models_and_Environment/`: model training, software, hardware and artifact identity coverage.
- `03_Precision_and_Graphs/`: blockwise discrepancies, precision selection, graph candidates, cloud repair and kernels.
- `04_Accuracy_and_Statistics/`: flood and cloud metrics, paired uncertainty and sensitivity analyses.
- `05_Performance_and_Reliability/`: compilation, controlled latency, runtime resources and sustained-operation measurements.
- `06_Provenance_and_Checks/`: manuscript correspondence, evidence sources, availability and file inventory.
- `sha256_manifest.txt`: file-integrity checksums, excluding the manifest itself.

## Interpretation of the evidence

Flood public-pool results are descriptive because the pool was accessed during configuration development. The formal cloud evaluation uses 300 previously unused, region-disjoint scenes; FP16 meets the task criteria and the mixed candidate fails the agreement requirement. Compilation records distinguish selected-merge work from complete-graph accounting. The isolated flood FP32 stability comparison uses Node 2. Results from different runners, graph structures, nodes or device-sharing conditions retain their respective measurement scopes.

## Data conventions and availability

CSV files use UTF-8 encoding and a header row. Units appear in column headings; GiB = 2^30 bytes. Numerical values retain their reported precision, and unavailable measurements are explicitly labelled. The 27 result CSV files correspond to Tables S1-S27; the other CSV files describe sources and file contents.

Source identifiers and hashes identify the manuscript and study records underlying the tables. Research code and selected derived records are publicly available at https://github.com/Undergraduate-Yan/Prithvi-deployment-on-the-Hygon-DCU-architecture. The code version associated with this manuscript is identified by commit 5cabcac5ff67f1e05e75a0aeff4451c0adede47d. The repository includes model preparation, numerical diagnostics, graph and precision operations, inference and analysis code, task configurations, artifact identities and selected scene-level derived records. The supplementary PDF and CSV tables provide the supporting methods and aggregate results. Additional study-authored code and derived data not subject to third-party restrictions are available from Jibing Qiu (qiujibing@ict.ac.cn) upon reasonable request. Third-party datasets and pretrained weights are obtained from their original providers. Raw imagery, labels, prediction tensors, task weights, ONNX/MXR payloads and vendor runtime binaries are not included in the repository; access remains subject to the applicable permissions. Dataset imagery, labels, model weights, ONNX/MXR payloads and raw prediction arrays are not redistributed here. Access to supporting data follows the article's Data Availability Statement and the asset-specific conditions in Table S27.
