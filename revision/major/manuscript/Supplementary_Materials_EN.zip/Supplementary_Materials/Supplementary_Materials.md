# Supplementary Materials

Onboard Deployment of Remote Sensing Foundation Models for the Hygon DCU Architecture

These supplementary materials detail the data roles, numerical compatibility analyses, precision and graph configurations, task evaluation and system measurements for the foundation-model deployment study. Flood public-pool results are interpreted descriptively, while the cloud task uses a frozen 300-scene formal evaluation. Performance and stability conclusions are limited to the stated ground-based experimental conditions.

# S1. Research scope and evaluation framework

This study investigates the deployment of remote sensing foundation models on the Hygon DCU architecture under joint constraints on numerical compatibility, compilation memory, deployment capacity and inference performance. Prithvi-EO-2.0-UPerNet is evaluated on flood and cloud segmentation to examine how precision assignment and execution-graph restructuring affect task predictions and computational requirements.

The two tasks provide different forms of evidence. The flood experiments characterize blockwise discrepancies, precision configurations and graph partitions, with final task scores reported descriptively because the 90-image public pool was accessed during development. The cloud experiments assess a frozen deployment on 300 previously unused, region-disjoint scenes. The separate 64-scene flood configuration set limits subsequent selection exposure but does not remove the effect of earlier public-pool feedback.

The evaluation distinguishes task accuracy, execution-provider placement, realized kernel paths, controlled latency and sustained-operation behavior. Their joint assessment is necessary because numerical agreement alone does not establish accelerator execution or performance, while smaller deployment files and faster kernels do not establish task acceptance. All experiments use ground-based K100 hardware; in-orbit operation, radiation qualification and spacecraft-level power or reliability are outside the demonstrated scope.

The supplementary analyses specify the dataset roles, model and software configurations, numerical diagnostics, graph-selection criteria, statistical procedures and measurement boundaries supporting the manuscript. Tables S1-S27 provide the associated quantitative evidence, and the accompanying CSV files make the tabulated results accessible for inspection. Data and artifact access conditions are described in Section S11.

## Table S1. Correspondence between the manuscript and supplementary evidence

| Manuscript location | Supplement sections | Evidence / scope |
| --- | --- | --- |
| 2.1-2.2; Table 1 | S3 | Model dimensions, task training, environment and artifact identity coverage |
| 2.3.1; 3.1.3; Table 5 | S5-S6 | Graph lineage, rejected merges and separately scoped compile costs |
| 2.3.2; 3.1.1 | S4 | Local diagnostics, C0-C5 candidates and equal-resource controls |
| 2.4; Table 2 | S2; S8 | Flood access events A01-A09, descriptive accuracy and bootstrap |
| 2.5; Table 2 | S2-S3; S7-S8 | Cloud training, independent formal scenes, repair and task acceptance |
| 3.1.2; Table 4; 3.2.3; Table 8 | S9 | Controlled model-call timing; process-level uncertainty |
| 3.1.3; Table 6; 3.2.3; Table 9 | S10 | Runtime memory, energy, startup, recovery and sustained loops |
| 4-5; Supplementary / Data Availability statements | S1; S11 | Reproducibility and access limits; no in-orbit validation |

Section numbers refer to the manuscript and this supplement.

CSV: `06_Provenance_and_Checks/manuscript_evidence_map.csv`

# S2. Dataset roles, preprocessing and access chronology

Sen1Floods11 supplies the flood case. Input bands are B02, B03, B04, B8A, B11 and B12, scaled by 1e-4 and resized to 224 x 224 using bilinear interpolation. Label resizing uses nearest-neighbor interpolation. Label -1 is ignored and label 1 is water. Flood normalization is embedded in the graph and must not be applied again outside it. Retained records do not fully identify every upstream band-resampling operation.

Separate sets of 64 training-derived scenes are used for calibration and configuration selection. The 89 official-validation images and 124 unused training images were not used for precision selection. The official-validation reserve, the 89 scenes with a defined per-scene flood mIoU, and the post-hoc clean-89 subset are three different concepts. The reserve is not presented as a completed independent evaluation.

CloudSEN12+ training comprises 5930 stored 509 x 509 observations from 1186 regions. Model validation comprises 535 observations from 107 regions, with 16 windows per observation (8560 model calls). A sample count, unique region count, crop/window count and inference-call count cannot be substituted for one another.

Formal cloud evaluation uses 300 previously unused 2000 x 2000 scenes. Both axes use tile starts {0, 224, 448, 672, 896, 1120, 1344, 1568, 1776}; their Cartesian product gives 81 calls per scene and 24,300 calls per variant. The final neighboring windows overlap by 16 pixels. Logits are averaged in overlaps before argmax and full-scene scoring. Scene reading, tiling, stitching and scoring are excluded from the model-call latency tables.

Cloud normalization is performed outside the graph using statistics from training regions only. A 975-sample, 195-region development evaluation is excluded from the 300-scene formal assessment. Disjointness is checked at the region, source-product, sample, generated-tile and content-hash levels, so the formal scene count is not inferred from a tile or observation count.

The access chronology in Table S3 establishes the evaluation roles. Events A01-A06 expose flood public-pool feedback before the C5 configuration and 13-segment topology are frozen. The stage-local counter at A08 measures only its own interval. A09 evaluates the frozen flood configuration descriptively, and A12 derives statistics from existing aggregate evidence without additional dataset access. These distinctions determine which results support configuration selection, descriptive assessment or independent formal evaluation.

## Table S2. Canonical data units and roles

| Task | Role | ROI/scene | Samples | Calls/sample | Status |
| --- | --- | --- | --- | --- | --- |
| Flood | official training | 431 | 431 | 1 | development only |
| Flood | calibration | 64 | 64 | 1 | quantization calibration only |
| Flood | configuration validation | 64 | 64 | 1 | precision selection and topology validation |
| Flood | official validation reserve | 89 | 89 | not accessed | not evaluated; future-confirmation eligibility not assessed |
| Flood | 90-image public-test pool | 90 | 90 | 1 per candidate | selection-exposed descriptive evaluation |
| Cloud | training | 1186 | 5930 | one random 224x224 crop per epoch | checkpoint training only |
| Cloud | model validation | 107 | 535 | 16 deterministic windows | checkpoint and early-stopping validation |
| Cloud | calibration | 256 | 1280 | registered calibration windows | quantization calibration only |
| Cloud | deployment validation | 256 | 1280 | registered deterministic windows | compile/numerical/system development |
| Cloud | 975-sample / 195-ROI development evaluation | 195 | 975 | registered windows | excluded from formal evaluation |
| Cloud | frozen 300-scene formal evaluation | 300 | 300 | 81 frozen 224x224 tiles | frozen formal evaluation |

ROI denotes region of interest. Counts of 5930 and 535 refer to sample observations rather than unique regions. The formal cloud evaluation comprises 300 full scenes.

CSV: `01_Data_and_Access/data_units.csv`

## Table S3. Project-level access chronology

| ID | Time | Task | n | Class | Scope |
| --- | --- | --- | --- | --- | --- |
| A01 | 2026-08-07 | Flood | 1 | selection-exposed | one image and target loaded for CPU/K100 mechanism check |
| A02 | 2026-08-07 | Flood | 90 | selection-exposed | complete FP32 evaluation with retained predictions |
| A03 | 2026-08-10 | Flood | 90 | selection-exposed | complete paired FP32/FP16 evaluation |
| A04 | 2026-08-10 | Flood | 90 | selection-exposed | complete mixed-provider INT8 diagnostic |
| A05 | 2026-08-10 | Flood | 90 | selection-exposed | complete strict-provider INT8 compatibility diagnostic |
| A06 | 2026-08-18 | Flood | 90 | selection-exposed | D0-D5 complete 90-image diagnostics; six candidates, three recorded runs each |
| A07 | 2026-08-20 | Flood | 90 | metadata-or-derived-only | identity and preprocessing replay; retained sample-ID/tensor misalignment reconstructed |
| A08 | 2026-08-22 | Flood | 0 | metadata-or-derived-only | stage-local ledger initialized at zero; not a project-level zero-access assertion |
| A09 | 2026-08-22 | Flood | 90 | inference-only | evaluation of the frozen configuration with per-scene predictions |
| A10 | 2026-08-24 | Cloud | 975 | inference-only | one evaluation-data access; excluded from the formal evaluation |
| A11 | 2026-08-25 | Cloud | 300 | inference-only | data materialized once; one formal evaluation per frozen variant; 24,300 calls per variant |
| A12 | 2026-08-28 | Flood and Cloud | 0 | metadata-or-derived-only | read-only confusion, margin, process-level latency CI, and clean-89 post-hoc derivations; no dataset payload or new inference |

Access dates establish the sequence of configuration development and evaluation. Flood public-pool results remain descriptive because the pool was accessed before configuration freezing.

CSV: `01_Data_and_Access/access_chronology.csv`

# S3. Models, training, environment and artifact identities

The deployment uses Prithvi-EO-2.0-UPerNet with a single temporal observation and input shape 1 x 6 x 224 x 224. The 24 Transformer blocks are indexed B0-B23; the decoder consumes feature taps from B5, B11, B17 and B23. The flood head has two output channels and the cloud head has four, ordered clear, thick cloud, thin cloud and cloud shadow (IDs 0-3).

The retained state-dictionary audit records 318,968,578 flood parameters and 318,969,092 cloud parameters. Cloud adaptation freezes the encoder and trains 15,082,756 decoder/head parameters. Training draws one random tile per observation per epoch and applies horizontal and vertical flips independently with probability 0.5.

Cloud weighted cross-entropy uses class weights 0.55048897, 0.78021453, 1.31386861 and 1.35542790. AdamW uses batch size 16, learning rate 5e-5, weight decay 0.05, gradient clipping 1.0, mixed-16 training and cosine scheduling with T_max=50. Early stopping uses minimum improvement 1e-4 and patience 8. Seed 42 selects epoch 29 at validation loss 0.3213295043; 39 epochs were completed.

Artifact identity is established by ordered ONNX/MXR manifests containing hashes, file sizes and input/output contracts. A read-only inventory on Node 1 and Node 3 identifies 42 cloud ONNX files and 42 cloud MXR files on each node: 14 sessions for FP32, FP16 and the rejected mixed candidate. This identity coverage does not include a complete operator-level inventory of all remote graphs. Parameter totals are obtained from the task-model state-dictionary audit.

Node labels denote three independent hosts with Hygon K100 AI accelerator cards. A live available-RAM snapshot is not an experiment-time compilation limit. The 47 GiB guard within a 48 GiB process budget concerns host memory during the applicable compile transactions, not device VRAM or the RAM of every inference node.

## Table S4. Software roles and retained versions

| Component | Version / setting | Role |
| --- | --- | --- |
| Accelerator | Hygon K100 AI | Target inference platform |
| Host CPU | Hygon C86 5380; 16 cores / 32 threads; 2 NUMA nodes | Host execution |
| Host / container OS | Ubuntu 20.04 / Ubuntu 22.04.5 | Separate host and container identities |
| ONNX Runtime | 1.19.2 | Deployed inference |
| MIGraphX | 5.1.0 | Execution provider / compiler |
| DTK / HIP | 25.04.2 / 6.3.25405 | Accelerator toolchain |
| PyTorch / ONNX | 2.5.1 / 1.22.0 | Model preparation and export |
| ONNX Runtime | 1.26.0 | Offline quantization only; not the deployed inference runtime |



CSV: `02_Models_and_Environment/software_environment.csv`

## Table S5. Three-node hardware snapshot

| Node | Kernel | Cores/threads | NUMA | RAM (GiB) | Available (GiB) | Swap (GiB) |
| --- | --- | --- | --- | --- | --- | --- |
| Node1 | 5.4.0-198-generic | 16/32 | 2 | 62.78 | 52.71 | 0.00 |
| Node2 | 5.4.0-216-generic | 16/32 | 2 | 15.60 | 7.04 | 8.00 |
| Node3 | 5.4.0-189-generic | 16/32 | 2 | 62.78 | 53.57 | 0.00 |

Snapshot date: 28 August 2026. Available RAM is time-dependent and is not a compile budget.

CSV: `02_Models_and_Environment/hardware_snapshot.csv`

## Table S6. Frozen ONNX/cache identity coverage

| Role | Sessions | ONNX (GiB) | MXR (GiB) | Manifest boundary |
| --- | --- | --- | --- | --- |
| Cloud-14S-FP16 | 14 | 0.595 | 0.660 | Hash+I/O complete; operators/parameters not inspected |
| Cloud-14S-FP32 | 14 | 1.189 | 1.320 | Hash+I/O complete; operators/parameters not inspected |
| Cloud-14S-MP-X | 14 | 0.583 | 0.645 | Hash+I/O complete; operators/parameters not inspected |
| Flood-13S-FP16 | 13 | 0.595 | 0.660 | Hash+I/O complete; operators/parameters not inspected |
| Flood-13S-FP32 | 13 | 1.189 | 1.317 | Hash+I/O complete; operators/parameters not inspected |
| Flood-13S-MP | 13 | 0.420 | 0.491 | Hash+I/O complete; operators/parameters not inspected |
| Flood-1S-FP16 | 1 | 0.595 | 0.660 | Hash+I/O complete; operators/parameters not inspected |
| Flood-1S-FP32 | 1 | 1.189 | 1.317 | Hash+I/O complete; operators/parameters not inspected |

Sizes are independently rounded. ONNX + MXR rounded subtotals need not reproduce the rounded bundle total exactly. Public repository manifests identify external models and caches; additional unrestricted identity records can be requested from the corresponding author. Model and cache payloads are not included. See Section S11.

CSV: `02_Models_and_Environment/artifact_identity_coverage.csv`

# S4. Blockwise diagnostics and precision selection

The diagnostic flood topology contains 25 sessions: session 0 includes normalization, patch embedding and B0; sessions 1-23 isolate B1-B23; session 24 contains the UPerNet decoder/head. FP32 OrtValues connect adjacent sessions and retain the four feature taps. This topology provides observability and a controlled graph-coarsening reference.

Let $f_i^C$ and $f_i^K$ denote the CPU and K100 block implementations; $x_i^C$ and $x_i^K$ are their accumulated inputs.

Local discrepancy:

$$L_i=\operatorname{MAE}\!\left(f_i^C(x_i^C),f_i^K(x_i^C)\right).$$

Cumulative discrepancy:

$$C_i=\operatorname{MAE}\!\left(f_i^C(x_i^C),f_i^K(x_i^K)\right).$$

Propagated discrepancy:

$$P_i=\operatorname{MAE}\!\left(f_i^K(x_i^C),f_i^K(x_i^K)\right).$$

Only the local comparison holds the input fixed. The 64-scene campaign yields $64\times24=1536$ finite block records. In the table, $s_i$ denotes the local same-input relative-$l_2$ discrepancy.

C5 protects blocks {0, 8, 10, 14, 15, 17, 18, 19, 20} in FP16. The ranking uses descending P90 local relative-l2 error, then descending local MAE P90, descending local maximum-error P90 and ascending block index. The remaining 15 blocks retain INT8/QDQ ancestry and the decoder/head remains floating point. C5 is a deterministic feasible configuration, not a proof of a global precision optimum.

Quantization is static QDQ with signed weights and activations, per-channel symmetric weights, per-tensor asymmetric activations and MinMax calibration on 64 scenes. The retained target scope comprises one Conv and 144 MatMul operators; LayerNorm, Softmax, required additions/resizes and outputs stay floating point as specified by the graph. Source QDQ nodes and deployed integer kernels are distinct evidence layers.

D0-D5 test the relationship between precision assignment and CPU/K100 logit discrepancies on selection-exposed inputs. Their FP16 block sets are none; {0}; {0,14}; {0,14,17}; {0,14,17,18}; and {0,14,15,16,17,18,19,20,21}, respectively, with an FP32 head. The diagnostic limits are MAE <= 1e-3, maximum error <= 5e-2 and agreement >= 0.999. Full FP16 has MAE 0.003715 and maximum error 0.013458; D0-D5 MAE ranges from 0.092546 to 0.126587. These measurements do not support tight CPU/K100 logit equivalence.

C0-C5 and equal-count controls evaluate precision policies on the separate configuration set. Random seed 43 scores slightly higher than C5, supporting the feasibility and deterministic selection of the discrepancy-ranked map rather than a claim of universal superiority. The D5 mechanism diagnostic and D5 control use different data-materialization and runner procedures; their task values must be interpreted within those respective procedures.

## Table S7. Local same-input block statistics on 64 configuration scenes

| Block i | P90 L_i | Local max-abs P90 | P90 s_i | C5 role |
| --- | --- | --- | --- | --- |
| 0 | 0.416115 | 3.645593 | 0.253082 | FP16 |
| 1 | 0.079506 | 2.336992 | 0.051495 | Q/DQ ancestry |
| 2 | 0.078029 | 1.507330 | 0.048810 | Q/DQ ancestry |
| 3 | 0.075157 | 1.437344 | 0.045820 | Q/DQ ancestry |
| 4 | 0.064253 | 1.739475 | 0.040141 | Q/DQ ancestry |
| 5 | 0.067225 | 1.022279 | 0.041207 | Q/DQ ancestry |
| 6 | 0.076672 | 0.766407 | 0.043209 | Q/DQ ancestry |
| 7 | 0.073881 | 1.432684 | 0.042516 | Q/DQ ancestry |
| 8 | 0.104673 | 0.737910 | 0.063427 | FP16 |
| 9 | 0.077894 | 1.000237 | 0.047338 | Q/DQ ancestry |
| 10 | 0.100061 | 1.927614 | 0.062349 | FP16 |
| 11 | 0.095798 | 1.131810 | 0.060090 | Q/DQ ancestry |
| 12 | 0.061186 | 1.162358 | 0.043103 | Q/DQ ancestry |
| 13 | 0.084361 | 0.651716 | 0.053114 | Q/DQ ancestry |
| 14 | 0.134388 | 0.904192 | 0.084799 | FP16 |
| 15 | 0.112157 | 0.652954 | 0.066702 | FP16 |
| 16 | 0.102729 | 1.059689 | 0.061651 | Q/DQ ancestry |
| 17 | 0.143484 | 1.389992 | 0.084360 | FP16 |
| 18 | 0.132540 | 1.010867 | 0.075834 | FP16 |
| 19 | 0.117198 | 0.999497 | 0.063972 | FP16 |
| 20 | 0.117701 | 0.719143 | 0.064704 | FP16 |
| 21 | 0.111782 | 0.679559 | 0.058097 | Q/DQ ancestry |
| 22 | 0.041474 | 0.307386 | 0.019772 | Q/DQ ancestry |
| 23 | 0.046387 | 0.589615 | 0.019227 | Q/DQ ancestry |

P90 denotes the 90th percentile across the retained scenes. L_i is MAE; s_i is relative-l2 error. Q/DQ ancestry is a source-graph property, not by itself proof of an integer kernel.

CSV: `03_Precision_and_Graphs/blockwise_discrepancy_64.csv`

## Table S8. Configuration candidates and equal-resource controls

| Candidate | FP16 blocks | mIoU | Water IoU | Boundary IoU | Agreement |
| --- | --- | --- | --- | --- | --- |
| Ctrl_early | 0, 1, 2, 3, 4, 5, 6, 7, 8 | 0.834565 | 0.694706 | 0.324149 | 0.999613 |
| Ctrl_late | 15, 16, 17, 18, 19, 20, 21, 22, 23 | 0.834164 | 0.693890 | 0.323704 | 0.998065 |
| Ctrl_D5 | 0, 14, 15, 16, 17, 18, 19, 20, 21 | 0.834696 | 0.694956 | 0.323731 | 0.999197 |
| C0 | none | 0.833972 | 0.693522 | 0.322493 | 0.998040 |
| C1 | 0 | 0.834658 | 0.694879 | 0.323029 | 0.999154 |
| C2 | 0, 14 | 0.834727 | 0.694990 | 0.322548 | 0.999186 |
| C3 | 0, 14, 17 | 0.834588 | 0.694735 | 0.322621 | 0.999171 |
| C4 | 0, 14, 17, 18 | 0.834733 | 0.695018 | 0.322953 | 0.999174 |
| C5 | 0, 8, 10, 14, 15, 17, 18, 19, 20 | 0.834708 | 0.694988 | 0.323702 | 0.999192 |
| Ctrl_U42 | 0, 2, 3, 4, 7, 8, 19, 20, 22 | 0.834743 | 0.695052 | 0.323465 | 0.999357 |
| Ctrl_U43 | 0, 1, 3, 4, 9, 11, 14, 15, 20 | 0.834763 | 0.695082 | 0.323922 | 0.999369 |
| Ctrl_U44 | 0, 3, 5, 7, 9, 12, 13, 16, 17 | 0.834590 | 0.694761 | 0.322972 | 0.999287 |
| Ctrl_U45 | 0, 2, 8, 9, 10, 13, 15, 19, 23 | 0.834629 | 0.694859 | 0.323036 | 0.999261 |
| Ctrl_U46 | 1, 2, 4, 7, 12, 16, 18, 20, 21 | 0.833897 | 0.693378 | 0.322618 | 0.998186 |
| Ctrl_runtime | 0, 2, 5, 7, 16, 18, 19, 21, 23 | 0.834691 | 0.694968 | 0.323988 | 0.999283 |
| Ctrl_task-sensitivity | 0, 3, 9, 12, 13, 14, 15, 16, 20 | 0.834540 | 0.694673 | 0.323311 | 0.999236 |

All candidates use the training-derived configuration set. U42-U46 identify the random-seed controls. The public-pool flood results are reported separately in Table S14.

CSV: `03_Precision_and_Graphs/configuration_candidates.csv`

# S5. Graph restructuring and rejected candidates

The final 13-session flood graph coarsens the diagnostic topology while retaining required feature outputs. Groups are {B0-B1}, {B2}, {B3}, {B4}, {B5}, {B6}, {B7-B10}, {B11-B14 with B11 retained}, {B15-B16}, {B17-B18 with B17 retained}, {B19-B20}, {B21-B22}, and {B23 + decoder/head}. Groups that contain feature taps preserve those taps explicitly.

The retained 25-to-13 equivalence check records MAE 2.205997e-7, maximum absolute error 1.6689301e-6, relative-l2 error 1.3301186e-7 and prediction agreement 1.0. This is a same-precision graph-restructuring check on its retained inputs, not a statement that every precision candidate is task-equivalent.

Graph selection requires both semantic equivalence and compliance with the host-memory budget. Memory-limited candidates do not constitute completed deployments, and numerically invalid merges are excluded irrespective of their session-count reduction. The 22-session graph is an auxiliary branch for selected merge combinations; its incomplete independent timing prevents its use as a fully measured point in the 25-to-13 session comparison.

The rejected candidates in Table S10 characterize the feasible deployment space under the numerical and resource constraints. The single-session mixed graph was not launched after the bounded stopping decision, so neither accuracy nor performance is assigned to that configuration.

## Table S9. Retained topology lineage

| Task | Sessions | Role | Interpretation |
| --- | --- | --- | --- |
| Flood | 25S | root | block-isolated diagnostic topology |
| Flood | 22S | auxiliary branch | Flood-22S-MP-Aux auxiliary candidate; independent timing incomplete |
| Flood | 21S | main branch | corrected controlled merge |
| Flood | 20S | main branch | fully compiled controlled candidate |
| Flood | 18S | main branch | controlled probe |
| Flood | 16S | prepared probe | not promoted as a final identity |
| Flood | 15S | main branch | controlled probe |
| Flood | 14S | main branch | controlled probe |
| Flood | 13S | final fair topology | empirical floor under registered compile budget and candidate set |
| Flood | 1S | production branch | monolithic FP32/FP16 only |
| Cloud | 13S | failed transfer | graph-context numerical failure |
| Cloud | 14S | repaired final topology | weight-preserving split of the failing context |

Graph labels identify distinct candidate roles. Auxiliary and attempted graphs are not accepted deployments.

CSV: `03_Precision_and_Graphs/topology_lineage.csv`

## Table S10. Rejected or uncompleted restructuring candidates

| Task / candidate | Observed outcome | Interpretation |
| --- | --- | --- |
| Flood B0-B2 merge | Host RSS about 47.03 GiB | Exceeds the 47 GiB guard; unusable under the stated guard |
| Flood B7-B14 retaining B11; B21-head | Host RSS about 47.09 GiB | Memory gate failed |
| Flood B13-B16; B15-B18; B19-B22 | CPU semantic checks failed | Rejected before promotion |
| Flood 5-session mixed | Host RSS 53.92 GiB; no complete cache set | Resource-blocked attempt |
| Flood 1-session mixed | Not launched after bounded stopping | No completed artifact or timing |
| Cloud B21 / B22 mixed trials | 58 GiB stopping limit reached | Uncompleted resource-limited trials |
| Cloud B17 mixed trial | Outer termination | No accepted compiled candidate |
| Cloud B23 mixed trial | Valid compiled candidate; formal agreement failed | Retained negative task result |



CSV: `03_Precision_and_Graphs/rejected_candidates.csv`

# S6. Compilation and deployment-bundle accounting

A deployment bundle comprises retained ONNX files plus compiled MXR caches. Its size is distinct from peak host RSS during compilation and incremental device memory during inference. GiB uses 2^30 bytes. Peak RSS is a peak measurement; compilation durations may cover all graph creation or only newly compiled sessions.

Table S11 reports complete-graph compilation costs. The 13-session mixed-precision time is a lower bound because durations for reused sessions are unavailable. Table S12 reports a selected-merge measurement of 1580.113591 s and 3.288097 GiB. That measurement covers a subset of graph construction, whereas the deployment-level accounting is >=2080.613 s and 3.978 GiB. The two records quantify different measurement scopes.

Cloud graph repair reuses 12 sessions and rebuilds two. Its incremental compilation measurements are FP32: 439.117 s and 3.270 GiB peak RSS; FP16: 473.783 s and 3.091 GiB. These are repair-only costs, not full cold-build totals. The retained cloud bundle sizes are 2,694,875,810 bytes (FP32), 1,347,179,966 bytes (FP16) and 1,319,407,483 bytes (rejected mixed candidate).

## Table S11. Flood complete-graph compilation costs and deployment-bundle size

| Sessions | Precision | Bundle (GiB) | Peak host RSS (GiB) | Compile time (s) |
| --- | --- | --- | --- | --- |
| 1 | FP16 | 1.255 | 7.640 | 1517.760 |
| 13 | FP32 | 2.506 | 4.233 | 1642.890 |
| 13 | FP16 | 1.255 | 4.048 | 1600.524 |
| 13 | Mixed C5 | 0.912 | 3.978 | >=2080.613 |

Corresponds to manuscript Table 5. Mixed-precision compilation time is a lower bound because reused-session durations are missing.

CSV: `05_Performance_and_Reliability/flood_compile.csv`

## Table S12. Compilation measurements by graph-construction scope

| Record | Role | S | Time (s) | Peak (GiB) | Scope |
| --- | --- | --- | --- | --- | --- |
| Initial uninstrumented record | Flood-1S-FP16-Diagnostic | 1 | not retained | not retained | timing not instrumented |
| Fresh single-Session build | Flood-1S-FP16 | 1 | 1517.759806 | 7.640 | Session creation; outer wall 1519.651678 s |
| 1S FP32 record | Flood-1S-FP32 | 1 | 1514.97598185 | not instrumented | complete retained compile records |
| 25S FP32 record | Flood-25S-FP32 | 25 | 1408.2397988880984 | not instrumented | complete retained compile records |
| 25S D5 control record | Flood-25S-D5-Control | 25 | not retained | not instrumented | timing not available |
| 5S mixed attempt | Flood-5S-MP-Attempt | 5 | not retained | 53.92 | blocked; no complete cache set |
| 1S mixed stop | Flood-1S-MP-Attempt | 1 | not launched | not instrumented | not launched after bounded stop |
| 22S auxiliary branch | Flood-22S-MP-Aux | 22 | 308.938867 | 3.553993 | selected merges only; reused time unavailable |
| 20S controlled branch | Flood-20S-MP | 20 | 567.435395 | 3.553993 | selected merges only; reused time unavailable |
| 13S mixed record | Flood-13S-MP | 13 | 1580.113591 | 3.288097 | selected merges only; reused time unavailable |

The 13S mixed-precision measurement in this table covers selected merges. Complete-graph accounting is reported in Table S11. Unavailable and uninstrumented measurements remain explicitly identified.

CSV: `05_Performance_and_Reliability/compile_measurement_scopes.csv`

# S7. Cloud numerical repair, provider placement and kernels

The cloud 13-session decoder graph fails near the first ConvTranspose in session 12: the retained full-session maximum error is 17.0303498507. A context-preserving 13-node subgraph tested on 32 development samples reproduces a maximum error of 18.0425862074, while isolated-operator controls give 2.00e-5 and 8.58e-6. This localizes the problem to the tested graph context without proving a universal defect in the operator.

Adding one validated boundary creates a 14-session graph without changing learned weights. The development evaluation gives FP32 mIoU 0.701050, FP16 mIoU 0.701080 and agreement 0.999524. These development numbers are not the 300-scene formal results. Repair and precision decisions precede formal-scene access.

Execution-provider placement and realized kernels complement the numerical evaluation. For the flood FP32, FP16 and mixed configurations, the 13-session placement summaries identify MIGraphX execution for all sessions and zero CPU sessions. Device traces establish the realized kernel paths associated with source-graph Q/DQ structures. Configuration labels such as RCS13-FP16-A are resolved through ordered artifact hashes and tensor contracts.

The final flood mixed graph contains 210 QuantizeLinear, 270 DequantizeLinear and 176 Cast nodes in the retained accounting, together with trace counts 4809 I8II and 1134 HBH. Counts from shorter representative traces have their own 20-repeat denominator. They cannot be summed into, or used as a replacement for, the full retained trace. A realized INT8 path does not imply lower latency or acceptable segmentation agreement.

## Table S13. Representative kernel traces and their scope

| Task / session group | I8II count | HBH count | Scope |
| --- | --- | --- | --- |
| Flood B0-B1 | 320 | 120 | Representative 20-repeat trace |
| Flood B7-B10 | 560 | 240 | Representative 20-repeat trace |
| Flood B11-B14 | 860 | 120 | Representative 20-repeat trace |
| Flood B23 + head | 320 | Not stated here | Representative integer-path count |
| Cloud rejected B23 candidate | 120 | Not stated here | Candidate trace; task gate failed |
| Cloud retained FP16 session | Not stated here | 240 | Retained FP16 path |

I8II and HBH are retained kernel-category labels. Unreported counts are not treated as zero. These measurements establish path realization under their trace scopes.

CSV: `03_Precision_and_Graphs/representative_kernel_paths.csv`

# S8. Accuracy, paired uncertainty and sensitivity analyses

Flood scores on the previously accessed 90-image pool are descriptive. The bootstrap uses 10,000 paired scene resamples with seed 42. Undefined per-scene metrics are omitted only from the corresponding summary. Pooled confusion-derived mIoU and the mean of defined per-scene mIoU values are different estimands; subtracting two pooled table values need not reproduce the mean paired scene difference.

Flood Boundary IoU uses a symmetric two-pixel band: dilate foreground and background with a 5 x 5 neighborhood, intersect the dilations and apply the valid-pixel mask. Its fixed custom definition is part of the metric contract. Allowed decreases are 0.005 for mIoU and 0.01 for water and boundary IoU; agreement must be at least 0.995. Descriptive margin checks do not correct adaptive-selection bias.

The clean-89 sensitivity analysis removes runtime index 0, whose recorded label Ghana_313799 differs from its actual source Ghana_1078550. The analysis assesses the influence of that source-identity discrepancy on the exposed public-pool results. As a post-hoc subset of the same pool, it is distinct from the unused official 89-image validation reserve and does not provide independent confirmation.

Cloud decisions use the frozen 300-scene protocol with 10,000 paired scene-bootstrap resamples and one-sided 95% lower bounds. Allowed decreases are 0.005 for mIoU and macro-F1, 0.01 for per-class IoU, and 0.005 for agreement relative to the FP32 reference agreement of 1. A lower bound on agreement difference is compared with -0.005. It is not an absolute agreement value.

FP16 meets the retained cloud criteria. The mixed candidate has observed agreement 0.994727 and a paired lower bound of -0.005969 on agreement difference, so it fails. Improvements in bundle size or latency do not reverse this decision. No replacement was selected using formal-set feedback.

The exploratory margin-sensitivity table varies hypothetical thresholds using already retained lower bounds. It is a descriptive sensitivity display; the registered decisions and tolerances remain unchanged. Class precision/recall/F1 are derived from retained confusion matrices with true labels as rows and predictions as columns.

## Table S14. Descriptive flood segmentation results

| Sessions | Precision | mIoU | Water IoU | Boundary IoU | Agreement |
| --- | --- | --- | --- | --- | --- |
| 1 | FP32 | 0.860587 | 0.757838 | 0.362581 | 1.000000 |
| 13 | FP32 | 0.860587 | 0.757838 | 0.362581 | 1.000000 |
| 13 | FP16 | 0.860443 | 0.757566 | 0.361941 | 0.999813 |
| 1 | FP16 | 0.860440 | 0.757563 | 0.361936 | 0.999814 |
| 13 | Mixed C5 | 0.860740 | 0.758114 | 0.363108 | 0.998745 |

Corresponds to manuscript Table 3. All scores describe the 90-image public pool, which was accessed during configuration development.

CSV: `04_Accuracy_and_Statistics/flood_accuracy.csv`

## Table S15. Flood paired scene-bootstrap descriptive screen

| Candidate | Metric | Difference | Lower 95% | Margin | Status |
| --- | --- | --- | --- | --- | --- |
| Flood-25S-D5-Control | miou | -0.000087 | -0.000802 | -0.005 | Within descriptive margin |
| Flood-25S-D5-Control | water_iou | -0.000218 | -0.001724 | -0.010 | Within descriptive margin |
| Flood-25S-D5-Control | Boundary IoU | -0.000094 | -0.001683 | -0.010 | Within descriptive margin |
| Flood-25S-D5-Control | agreement | -0.001332 | -0.001758 | -0.005 | Within descriptive margin |
| Flood-13S-MP | miou | -0.000211 | -0.000833 | -0.005 | Within descriptive margin |
| Flood-13S-MP | water_iou | -0.000494 | -0.001750 | -0.010 | Within descriptive margin |
| Flood-13S-MP | Boundary IoU | 0.000384 | -0.000704 | -0.010 | Within descriptive margin |
| Flood-13S-MP | agreement | -0.001304 | -0.001738 | -0.005 | Within descriptive margin |
| Flood-1S-FP16 | miou | -0.000268 | -0.000400 | -0.005 | Within descriptive margin |
| Flood-1S-FP16 | water_iou | -0.000569 | -0.000840 | -0.010 | Within descriptive margin |
| Flood-1S-FP16 | Boundary IoU | -0.000363 | -0.000757 | -0.010 | Within descriptive margin |
| Flood-1S-FP16 | agreement | -0.000189 | -0.000253 | -0.005 | Within descriptive margin |
| Flood-1S-FP32 | miou | 0.000000 | 0.000000 | -0.005 | Within descriptive margin |
| Flood-1S-FP32 | water_iou | 0.000000 | 0.000000 | -0.010 | Within descriptive margin |
| Flood-1S-FP32 | Boundary IoU | 0.000000 | 0.000000 | -0.010 | Within descriptive margin |
| Flood-1S-FP32 | agreement | 0.000000 | 0.000000 | -0.005 | Within descriptive margin |
| Flood-13S-FP16 | miou | -0.000253 | -0.000381 | -0.005 | Within descriptive margin |
| Flood-13S-FP16 | water_iou | -0.000538 | -0.000796 | -0.010 | Within descriptive margin |
| Flood-13S-FP16 | Boundary IoU | -0.000329 | -0.000732 | -0.010 | Within descriptive margin |
| Flood-13S-FP16 | agreement | -0.000191 | -0.000254 | -0.005 | Within descriptive margin |

Difference is candidate minus its paired reference for the stated scene-level metric. The retained mean paired mIoU differences are not differences of pooled mIoU values. No independent-confirmation interpretation is made.

CSV: `04_Accuracy_and_Statistics/flood_descriptive_bootstrap.csv`

## Table S16. Post-hoc clean-89 flood sensitivity

| Role | mIoU | Water IoU | Boundary IoU | Pixel acc. | Agreement |
| --- | --- | --- | --- | --- | --- |
| Flood-13S-MP | 0.861906 | 0.760366 | 0.365063 | 0.967244 | 0.998736 |
| Flood-13S-FP16 | 0.861607 | 0.759816 | 0.363858 | 0.967196 | 0.999810 |
| Flood-13S-FP32 | 0.861751 | 0.760088 | 0.364506 | 0.967214 | 1.000000 |

Removal of runtime index 0 is post hoc and does not create an independent test set.

CSV: `04_Accuracy_and_Statistics/flood_clean89_posthoc.csv`

## Table S17. Formal cloud segmentation results

| Metric | FP32 | FP16 | Mixed candidate |
| --- | --- | --- | --- |
| mIoU | 0.612601 | 0.612581 | 0.612098 |
| Macro-F1 | 0.736891 | 0.736860 | 0.736416 |
| Pixel accuracy | 0.866554 | 0.866591 | 0.866405 |
| Clear IoU | 0.867286 | 0.867366 | 0.866653 |
| Thick-cloud IoU | 0.788892 | 0.788902 | 0.789275 |
| Thin-cloud IoU | 0.411542 | 0.411500 | 0.409902 |
| Cloud-shadow IoU | 0.382683 | 0.382556 | 0.382562 |
| Agreement | 1.000000 | 0.999371 | 0.994727 |
| mIoU difference lower bound | Reference | -0.000089 | -0.001370 |
| Agreement difference lower bound | Reference | -0.000725 | -0.005969 |
| Decision | Reference | Accepted | Rejected |

Corresponds to manuscript Table 7. All variants use the 14-session cloud topology. The formal evaluation contains 300 full scenes and 24,300 tile calls per variant.

CSV: `04_Accuracy_and_Statistics/cloud_accuracy.csv`

## Table S18. Complete formal cloud paired scene-bootstrap results

| Candidate | Metric | Difference | Lower 95% | Margin | Status |
| --- | --- | --- | --- | --- | --- |
| Cloud-14S-FP16 | mIoU | -0.000020 | -0.000089 | -0.005 | PASS |
| Cloud-14S-FP16 | MacroF1 | -0.000031 | -0.000096 | -0.005 | PASS |
| Cloud-14S-FP16 | clear_IoU | 0.000079 | 0.000021 | -0.010 | PASS |
| Cloud-14S-FP16 | thick_cloud_IoU | 0.000010 | -0.000069 | -0.010 | PASS |
| Cloud-14S-FP16 | thin_cloud_IoU | -0.000042 | -0.000210 | -0.010 | PASS |
| Cloud-14S-FP16 | cloud_shadow_IoU | -0.000127 | -0.000263 | -0.010 | PASS |
| Cloud-14S-FP16 | agreement | -0.000629 | -0.000725 | -0.005 | PASS |
| Cloud-14S-MP-X | mIoU | -0.000503 | -0.001370 | -0.005 | PASS |
| Cloud-14S-MP-X | MacroF1 | -0.000475 | -0.001307 | -0.005 | PASS |
| Cloud-14S-MP-X | clear_IoU | -0.000634 | -0.001272 | -0.010 | PASS |
| Cloud-14S-MP-X | thick_cloud_IoU | 0.000383 | -0.000461 | -0.010 | PASS |
| Cloud-14S-MP-X | thin_cloud_IoU | -0.001640 | -0.003737 | -0.010 | PASS |
| Cloud-14S-MP-X | cloud_shadow_IoU | -0.000121 | -0.002217 | -0.010 | PASS |
| Cloud-14S-MP-X | agreement | -0.005273 | -0.005969 | -0.005 | FAIL |

Difference is candidate minus reference; bounds are one-sided 95% lower bounds. PASS/FAIL is retained per criterion. The mixed candidate is rejected because of agreement.

CSV: `04_Accuracy_and_Statistics/cloud_formal_bootstrap.csv`

## Table S19. Cloud absolute class and binary aggregation metrics

| Role | Aggregation | Class | Prev. | Precision | Recall | F1 | IoU |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Cloud-14S-FP32 | four_class | Clear | 0.6489 | 0.9112 | 0.9473 | 0.9289 | 0.8673 |
| Cloud-14S-FP32 | four_class | Thick Cloud | 0.1961 | 0.9188 | 0.8481 | 0.8820 | 0.7889 |
| Cloud-14S-FP32 | four_class | Thin Cloud | 0.0834 | 0.5437 | 0.6287 | 0.5831 | 0.4115 |
| Cloud-14S-FP32 | four_class | Cloud Shadow | 0.0715 | 0.6901 | 0.4621 | 0.5535 | 0.3827 |
| Cloud-14S-FP32 | clear_vs_any_cloud | Any Cloud | 0.3511 | 0.8949 | 0.8295 | 0.8609 | 0.7558 |
| Cloud-14S-FP16 | four_class | Clear | 0.6489 | 0.9112 | 0.9474 | 0.9290 | 0.8674 |
| Cloud-14S-FP16 | four_class | Thick Cloud | 0.1961 | 0.9187 | 0.8481 | 0.8820 | 0.7889 |
| Cloud-14S-FP16 | four_class | Thin Cloud | 0.0834 | 0.5437 | 0.6286 | 0.5831 | 0.4115 |
| Cloud-14S-FP16 | four_class | Cloud Shadow | 0.0715 | 0.6907 | 0.4617 | 0.5534 | 0.3826 |
| Cloud-14S-FP16 | clear_vs_any_cloud | Any Cloud | 0.3511 | 0.8951 | 0.8294 | 0.8610 | 0.7559 |

Prev. means class prevalence. The any-cloud aggregation combines the three non-clear classes. Rounded display metrics do not replace the retained full-precision confusion matrices.

CSV: `04_Accuracy_and_Statistics/cloud_class_metrics.csv`

## Table S20. Exploratory practical-margin sensitivity

| Task | Role | Metric | Lower bound | .0001 | .0005 | .001 | .0025 | .005 | .01 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| flood | Flood-13S-MP | miou | -8.328e-04 | Fail | Fail | Pass | Pass | Pass | Pass |
| flood | Flood-13S-FP16 | miou | -3.811e-04 | Fail | Pass | Pass | Pass | Pass | Pass |
| cloud | Cloud-14S-FP16 | mIoU | -8.916e-05 | Pass | Pass | Pass | Pass | Pass | Pass |
| cloud | Cloud-14S-MP-X | agreement | -5.969e-03 | Fail | Fail | Fail | Fail | Fail | Pass |

Threshold columns are hypothetical tolerated decreases. Registered acceptance decisions are unchanged.

CSV: `04_Accuracy_and_Statistics/margin_sensitivity.csv`

# S9. Controlled latency and process-level uncertainty

Controlled short-run measurements use five fresh processes per node and variant, 50 warm-up calls and 200 measured calls per process, giving 1000 measured calls. CPU affinity is fixed and competing accelerator processes are excluded. Common C++ Runner-A timing includes every session, final synchronization and the transfer of FP32 logits to the host.

The single-session flood comparison uses a separately fixed Python I/O-binding runner. Comparisons should be made within runner, topology and node. A cross-runner difference does not isolate the effect of graph segmentation or precision. The cloud comparison holds the 14-session topology and Runner-A fixed.

The manuscript reports pooled-call medians and tail percentiles. The process-level analysis reports the median of five process medians and bootstraps those process-level values with 10,000 replicates and seed 42. It estimates between-process uncertainty under the same measurement protocol. Its interpretation is limited by the number of processes and by the exclusion of scene loading, tiling, stitching and scoring.

Configuration-validation measurements use 3 x 100 or 10 x 200 diagnostic calls to characterize graph-reduction candidates. Their scope differs from the five-process controlled deployment benchmark. Sustained-loop throughput additionally includes scheduling, telemetry and integrity checks. Each measurement addresses a distinct aspect of deployment behavior and is reported with its corresponding protocol.

## Table S21. Controlled flood model-call latency

| Runner / topology | Node | Precision | Median (ms) | P95 (ms) | P99 (ms) |
| --- | --- | --- | --- | --- | --- |
| Python / 1S | 2 | FP32 | 19.133 | 21.086 | 23.698 |
| Python / 1S | 2 | FP16 | 14.704 | 16.661 | 19.321 |
| Python / 1S | 3 | FP32 | 19.858 | 22.267 | 25.075 |
| Python / 1S | 3 | FP16 | 15.288 | 16.962 | 20.225 |
| Runner-A / 13S | 2 | FP32 | 34.912 | 36.967 | 40.040 |
| Runner-A / 13S | 2 | FP16 | 32.094 | 33.981 | 36.737 |
| Runner-A / 13S | 2 | Mixed C5 | 39.180 | 41.257 | 43.651 |
| Runner-A / 13S | 3 | FP32 | 33.153 | 35.217 | 36.776 |
| Runner-A / 13S | 3 | FP16 | 30.132 | 31.565 | 32.680 |
| Runner-A / 13S | 3 | Mixed C5 | 37.932 | 39.843 | 40.930 |

Corresponds to manuscript Table 4. Each row includes 1000 measured calls across five processes.

CSV: `05_Performance_and_Reliability/flood_latency.csv`

## Table S22. Cloud model-call latency on the 14-session topology

| Node | Precision | Median (ms) | P95 (ms) | P99 (ms) |
| --- | --- | --- | --- | --- |
| 1 | FP32 | 36.612 | 42.179 | 49.653 |
| 1 | FP16 | 33.060 | 38.302 | 44.318 |
| 1 | Mixed candidate | 32.267 | 36.880 | 42.507 |
| 3 | FP32 | 34.528 | 37.503 | 45.223 |
| 3 | FP16 | 31.006 | 34.473 | 40.878 |
| 3 | Mixed candidate | 30.884 | 33.870 | 39.904 |

Corresponds to manuscript Table 8. The mixed candidate fails the task-agreement requirement despite its measured latency.

CSV: `05_Performance_and_Reliability/cloud_latency.csv`

## Table S23. Cloud process-level latency uncertainty

| Node | Role | Processes | Calls | Median of medians (ms) | 95% CI (ms) |
| --- | --- | --- | --- | --- | --- |
| Node1 | Cloud-14S-FP16 | 5 | 1000 | 32.701 | [32.423, 33.971] |
| Node1 | Cloud-14S-FP32 | 5 | 1000 | 36.600 | [35.961, 37.608] |
| Node1 | Cloud-14S-MP-X | 5 | 1000 | 32.422 | [31.647, 32.707] |
| Node3 | Cloud-14S-FP16 | 5 | 1000 | 30.805 | [30.711, 31.598] |
| Node3 | Cloud-14S-FP32 | 5 | 1000 | 34.508 | [34.313, 34.854] |
| Node3 | Cloud-14S-MP-X | 5 | 1000 | 30.846 | [30.495, 31.375] |

Median of process medians differs from the pooled-call median in the preceding table. Confidence intervals use the retained five fresh-process medians.

CSV: `05_Performance_and_Reliability/cloud_process_latency_ci.csv`

## Table S24. Configuration-validation latency for graph-reduction candidates

| Configuration | Protocol | S | Calls | Median (ms) | P95 (ms) |
| --- | --- | --- | --- | --- | --- |
| Flood-1S-FP32 | 3 x 100 characterization | 1 | 300 | 17.197 | 18.934 |
| Flood-1S-FP16-Diagnostic | 3 x 100 characterization | 1 | 300 | 13.324 | 13.717 |
| Flood-25S-FP32 | 3 x 100 characterization | 25 | 300 | 20.847 | 22.594 |
| Flood-25S-D5-Control | 3 x 100 characterization | 25 | 300 | 21.373 | 23.558 |
| Flood-13S-MP | 3 x 100 characterization | 13 | 300 | 19.253 | 21.274 |
| Flood-1S-FP32 | 10 x 200 repeat characterization | 1 | 2000 | 17.278 | 20.815 |
| Flood-1S-FP16-Diagnostic | 10 x 200 repeat characterization | 1 | 2000 | 13.393 | 13.888 |
| Flood-13S-MP | 10 x 200 repeat characterization | 13 | 2000 | 19.263 | 21.534 |

These configuration-validation protocols characterize graph-reduction candidates and are separate from the five-process controlled benchmark.

CSV: `05_Performance_and_Reliability/configuration_graph_reduction_latency.csv`

# S10. Runtime resources, startup, recovery and sustained operation

Incremental device memory is distinct from the ONNX+MXR bundle on disk. The flood resource experiment samples device memory at 20 Hz and power at 10 Hz; energy per completed call is obtained by trapezoidal integration. Flood energy is gross energy per model call. Cloud energy subtracts idle power and is incremental energy per tile; these two energy measures are not directly comparable.

Startup spans process initialization through the first valid prediction while retaining filesystem caches. Recovery follows deliberate process termination and restart. Flood startup and recovery use ten and five valid repetitions, respectively. These definitions are not a measurement of spacecraft boot or radiation-fault recovery.

The isolated flood FP32 stability experiment on Node 2 runs for 3600.004154 s and completes 151,580 calls with zero errors, non-finite outputs or prediction drift. All 719 active KFD telemetry records belong to the experiment, with no foreign KFD records. This exclusivity condition supports attribution of the monitored device activity to the evaluated configuration.

A separate partly shared FP32 experiment on Node 3 completes 165,912 calls. Because device exclusivity is incomplete, this run is excluded from the isolated comparison in Table S25 and manuscript Table 6. The distinction is based on measurement conditions and prevents competing device activity from being interpreted as a precision effect.

Flood FP16 and mixed sustained records complete 215,971 and 151,370 calls, respectively, in approximately one hour, without recorded errors or non-finite outputs. Cloud sustained records complete 139,017 FP32 calls on Node 3 and 145,192 FP16 calls on Node 2 over their retained durations. Cross-node system differences are descriptive and cannot be attributed to precision alone.

Sustained loops include monitoring and integrity checks. Their calls-per-second rates must not be substituted for the controlled short-run latency statistics. Zero observed failures in these runs is an observation over these durations and conditions, not an estimate of unrestricted mission reliability.

## Table S25. Flood runtime resources and sustained-operation results

| Metric | 1S FP32 | 1S FP16 | 13S Mixed C5 |
| --- | --- | --- | --- |
| Incremental device memory (GiB) | 4.817 | 3.149 | 10.682 |
| Gross energy (J/call) | 5.352 | 3.531 | 4.653 |
| Median startup (s) | 23.115 | 18.723 | 17.033 |
| Median recovery (s) | 33.988 | 29.090 | 27.819 |
| Calls in approximately 3600 s | 151580 | 215971 | 151370 |
| Errors / non-finite outputs | 0 / 0 | 0 / 0 | 0 / 0 |

Corresponds to manuscript Table 6. The FP32 sustained-operation result uses the isolated Node 2 experiment. The partly shared Node 3 experiment is excluded from this comparison.

CSV: `05_Performance_and_Reliability/flood_runtime.csv`

## Table S26. Cloud runtime resources and sustained-operation results

| Metric | FP32 | FP16 |
| --- | --- | --- |
| Resource-measurement node | 3 | 1 |
| Incremental device memory (GiB) | 12.462 | 10.893 |
| Incremental energy above idle (J/tile) | 4.890 | 1.957 |
| Median startup (s) | 29.187 | 25.769 |
| Median recovery (s) | 28.986 | 25.774 |
| Sustained-operation node | 3 | 2 |
| Duration (s) | 5111.418 | 5349.822 |
| Completed calls | 139017 | 145192 |
| Errors / prediction drift | 0 / 0 | 0 / 0 |

Corresponds to manuscript Table 9. Resource and sustained-operation measurements use different node assignments; cross-node differences do not isolate precision effects.

CSV: `05_Performance_and_Reliability/cloud_runtime.csv`

# S11. Data and code availability and reproducibility

Sen1Floods11 imagery and labels are available from https://github.com/cloudtostreet/Sen1Floods11. CloudSEN12+ imagery and labels are available from https://huggingface.co/datasets/tacofoundation/cloudsen12; the source metadata used in this study is identified by repository revision f9490f7de11b4f387f72ef800e73ccbb754711de. Prithvi initialization and official task weights are obtained from the IBM-NASA Geospatial model repositories (https://huggingface.co/ibm-nasa-geospatial). These sources correspond to the datasets and models cited in the manuscript. Their applicable terms govern use and redistribution.

The supplementary tables and CSV files report study-level results at the stated numerical precision, with units and missing-value labels. The public code repository supplies task configurations, dataset selection identifiers, model/cache identities, supplementary tables and selected scene-level derived records. Table S27 distinguishes the materials included in this supplement, those available in the repository and those requiring an external source or a request to the corresponding author.

Research code and selected derived records are publicly available at https://github.com/Undergraduate-Yan/Prithvi-deployment-on-the-Hygon-DCU-architecture. The code version associated with this manuscript is identified by commit 5cabcac5ff67f1e05e75a0aeff4451c0adede47d. The repository includes model preparation, numerical diagnostics, graph and precision operations, inference and analysis code, task configurations, artifact identities and selected scene-level derived records. The supplementary PDF and CSV tables provide the supporting methods and aggregate results. Additional study-authored code and derived data not subject to third-party restrictions are available from Jibing Qiu (qiujibing@ict.ac.cn) upon reasonable request. Third-party datasets and pretrained weights are obtained from their original providers. Raw imagery, labels, prediction tensors, task weights, ONNX/MXR payloads and vendor runtime binaries are not included in the repository; access remains subject to the applicable permissions.

Study-authored software and its accompanying software documentation and configuration files are provided under the Apache License 2.0, as specified in the repository LICENSE and licensing documentation. Third-party components and dataset-derived records retain their applicable terms. Publicly included records can be obtained directly from the repository. Additional prediction outputs, timing records, detailed diagnostic records and other derived data not subject to third-party restrictions are available from the corresponding author upon reasonable request. Source dataset providers supply imagery and labels, not the predictions generated by this study.

Reproducing the deployment requires the specified datasets, task checkpoints, software stack and licensed vendor components in addition to the public code and documented graph and precision configurations. Repository manifests identify external artifacts through hashes and input/output contracts; the identifiers do not replace the artifact payloads. Some construction procedures also require exact calibration manifests, development inputs and build reports. The available evidence does not fully specify every upstream flood band-resampling operation. Access to additional experimental configurations and manifests follows the conditions above. The repository alone is not a self-contained package for full hardware replication.

File checksums support the identification and integrity of the supplementary evidence. Scientific reproducibility additionally depends on matching the data roles, artifact identities, numerical criteria and measurement protocols described in this supplement. Independent confirmation of flood generalization and full-scene onboard performance requires evidence beyond the ground-based experiments reported here.

## Table S27. Availability by evidence type

| Material | Included here | Access / limitation |
| --- | --- | --- |
| Supplementary methods and aggregate results | PDF, Markdown and CSV | Included in this supplement |
| Dataset imagery and labels | No | Original dataset providers; applicable dataset terms |
| Study-generated prediction outputs | No | Corresponding author upon reasonable request, where free of third-party restrictions |
| Pretrained initialization and official task weights | No | Original model providers; applicable model terms |
| Study-trained checkpoints and exported ONNX models | No | Request access from the corresponding author; applicable model and third-party permissions |
| Compiled MXR artifacts and vendor components | No | Access or rebuilding subject to applicable vendor and third-party permissions |
| Split/access identifiers and model/cache hashes | No | Public selection and artifact manifests in the repository; additional unrestricted records upon reasonable request |
| Per-scene and per-call derived data | No | Selected scene records publicly available in the repository; additional unrestricted records upon reasonable request |
| Research code and analysis scripts | No | Public GitHub repository at the commit specified in Section S11; additional unrestricted code upon reasonable request |
| Evidence source index and file checksums | Yes | Included in this supplement |



CSV: `06_Provenance_and_Checks/availability_matrix.csv`
